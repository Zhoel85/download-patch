<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?= $judul; ?> </title>

    <!-- Bootstrap -->
    <link href="<?= base_url(); ?>assets/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?= base_url(); ?>assets/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="<?= base_url(); ?>assets/vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- Animate.css -->
    <link href="<?= base_url(); ?>assets/vendors/animate.css/animate.min.css" rel="stylesheet">
    <link rel="icon" href="<?= base_url('assets/logo/sarlogo.png') ?>" type="image/ico" />

    <!-- Custom Theme Style -->
    <link href="<?= base_url(); ?>assets/build/css/custom.min.css" rel="stylesheet">
</head>

<body class="login">
    <div>

        <div class="login_wrapper">
            <div class="animate form login_form">
                <section class="login_content">
                    <center><img class="mb-1" src="<?= base_url('assets/logo/sarlogo.png'); ?>" height="150px" alt="SAR SYSTEM ONLINE"></center>
                    <form action="<?= base_url('Auth'); ?>" method="post">
                        <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                        <h1>ADMINISTRATOR</h1>
                        <div>
                            <?= form_error('username', '<small class="text-danger">', '</small>'); ?>
                            <input type="text" name="username" class="form-control" placeholder="Username">
                        </div>
                        <div>
                            <?= form_error('password', '<small class="text-danger">', '</small>'); ?>
                            <input type="password" name="password" class="form-control" placeholder="Password">
                        </div>
                        <div>
                            <button class="btn btn-primary submit" type="submit" href="<?= base_url('Auth'); ?>">MASUK</button>
                            <!-- <a class="btn btn-info" href="<?= base_url('Authanggota'); ?>">MASUK ANGGOTA</a> -->
                        </div>

                        <a href="<?= base_url('Authanggota'); ?>" class="btn btn-danger btn-sm">Masuk Anggota</a>

                        <div class="clearfix"></div>

                        <div class="separator">
                            <!-- <p class="change_link">New to site?
                                <a href="#signup" class="to_register"> Create Account </a>
                            </p>

                            <div class="clearfix"></div>
                            <br /> -->

                            <div>
                                <h1>SAR | DIGITAL</h1>
                                <?= $this->session->flashdata('pesan'); ?>
                                <p>© <?= date('Y'); ?> . SYAHARUDDIN ALRIF | SAHABAT SAR</p>
                            </div>
                        </div>
                    <div class="form-group text-center"><a href="<?= base_url('PasswordReset/request/user'); ?>">Lupa password?</a></div>
                            </form>
                </section>
            </div>
        </div>
    </div>
</body>

</html>
<script>
    <?php if ($this->session->flashdata('pesan_delete')) { ?>
        var isi = <?php echo json_encode($this->session->flashdata('pesan_delete')) ?>;
        Swal.fire({
            title: isi,
            html: 'Sedang menghapus <b></b> detik.',
            timer: 2000,
            timerProgressBar: true,
            didOpen: () => {
                Swal.showLoading()
                const b = Swal.getHtmlContainer().querySelector('b')
                timerInterval = setInterval(() => {
                    b.textContent = Swal.getTimerLeft()
                }, 100)
            },
            willClose: () => {
                clearInterval(timerInterval)
            }
        }).then((result) => {
            /* Read more about handling dismissals below */
            if (result.dismiss === Swal.DismissReason.timer) {
                console.log('I was closed by the timer')
            }
        })
    <?php } ?>

    <?php if ($this->session->flashdata('gagal')) { ?>
        var isi = <?php echo json_encode($this->session->flashdata('gagal')) ?>;
        Swal.fire({
            // position: 'top-end',
            position: 'top',
            icon: 'error',
            title: isi,
            showConfirmButton: false,
            timer: 1500
        })
    <?php } ?>
</script>