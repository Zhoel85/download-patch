<!doctype html>
<html lang="en">

<head>
    <title>Login SAR DIGITAL</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <link rel="stylesheet" href="<?= base_url(); ?>assets/loginuser/css/style.css">
    <link rel="icon" href="<?= base_url('assets/logo/logo.png') ?>" type="image/ico" />

</head>

<body>
    <section class="ftco-section">
        <div class="container">
            <!-- <div class="row justify-content-center">
                <div class="col-md-6 text-center mb-5">
                    <h2 class="heading-section">SAR DIGITAL</h2>
                </div>
            </div> -->
            <div class="row justify-content-center">
                <div class="col-md-12 col-lg-10">
                    <div class="wrap d-md-flex">
                        <!-- <img src="<?= base_url(); ?>assets/loginuser/images/bg-1.jpg" height="100px" alt=""> -->
                        <div class="img" style="background-image: url(<?= base_url(); ?>assets/loginuser/images/bg-1.jpg);">
                        </div>
                        <div class="login-wrap p-4 p-md-5">
                            <div class="d-flex">
                                <div class="w-100">
                                    <h3 class="mb-4">SAR DIGITAL</h3>
                                </div>
                                <div class="w-100">
                                    <!-- <p class="social-media d-flex justify-content-end">
                                        <a href="#" class="social-icon d-flex align-items-center justify-content-center"><span class="fa fa-facebook"></span></a>
                                        <a href="#" class="social-icon d-flex align-items-center justify-content-center"><span class="fa fa-twitter"></span></a>
                                    </p> -->
                                </div>
                            </div>
                            <form action="<?= base_url('Authanggota'); ?>" method="post">
                        <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                                <div class="form-group mb-3">
                                    <label class="label" for="name">Username</label>
                                    <input type="text" name="username" class="form-control" placeholder="Username" value="<?= set_value('username'); ?>">
                                    <?= form_error('username', '<small class="text-danger">', '</small>'); ?>
                                </div>
                                <div class="form-group mb-3">
                                    <label class="label" for="password">Password</label>
                                    <input type="password" name="password" class="form-control" placeholder="Password">
                                    <?= form_error('password', '<small class="text-danger">', '</small>'); ?>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="form-control btn btn-primary rounded submit px-3">Masuk</button>
                                </div>
                                <div class="form-group text-center">
                                    <a class="text-center" href="<?= base_url('Auth'); ?>">Masuk admin</a>
                                </div>
                                <!-- <div class="form-group d-md-flex">
                                    <div class="w-50 text-left">
                                        <label class="checkbox-wrap checkbox-primary mb-0">Remember Me
                                            <input type="checkbox" checked>
                                            <span class="checkmark"></span>
                                        </label>
                                    </div>
                                    <div class="w-50 text-md-right">
                                        <a href="#">Forgot Password</a>
                                    </div>
                                </div> -->
                            <div class="form-group text-center"><a href="<?= base_url('PasswordReset/request/anggota'); ?>">Lupa password?</a></div>
                            </form>
                            <!-- <p class="text-center">Not a member? <a data-toggle="tab" href="#signup">Sign Up</a></p> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="<?= base_url(); ?>assets/loginuser/js/jquery.min.js"></script>
    <script src="<?= base_url(); ?>assets/loginuser/js/popper.js"></script>
    <script src="<?= base_url(); ?>assets/loginuser/js/bootstrap.min.js"></script>
    <script src="<?= base_url(); ?>assets/loginuser/js/main.js"></script>

</body>

</html>

<script>
    <?php if ($this->session->flashdata('pesan_delete')) { ?>
        var isi = <?php echo json_encode($this->session->flashdata('pesan_delete')) ?>;
        Swal.fire({
            title: isi,
            html: 'Sedang menghapus <b></b> detik.',
            timer: 2000,
            timerProgressBar: true,
            didOpen: () => {
                Swal.showLoading()
                const b = Swal.getHtmlContainer().querySelector('b')
                timerInterval = setInterval(() => {
                    b.textContent = Swal.getTimerLeft()
                }, 100)
            },
            willClose: () => {
                clearInterval(timerInterval)
            }
        }).then((result) => {
            /* Read more about handling dismissals below */
            if (result.dismiss === Swal.DismissReason.timer) {
                console.log('I was closed by the timer')
            }
        })
    <?php } ?>

    <?php if ($this->session->flashdata('gagal')) { ?>
        var isi = <?php echo json_encode($this->session->flashdata('gagal')) ?>;
        Swal.fire({
            // position: 'top-end',
            position: 'top',
            icon: 'error',
            title: isi,
            showConfirmButton: false,
            timer: 1500
        })
    <?php } ?>
</script>