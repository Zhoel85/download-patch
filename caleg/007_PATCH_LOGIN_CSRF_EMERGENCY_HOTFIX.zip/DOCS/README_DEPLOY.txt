007_PATCH_LOGIN_CSRF_EMERGENCY_HOTFIX

PENYEBAB:
PHASE 001 mengaktifkan CSRF global, tetapi halaman login Auth/Authanggota adalah standalone dan tidak melewati template/footer yang menyisipkan token otomatis.
Akibatnya POST login ditolak CI3 sebelum controller dijalankan dengan pesan:
"The action you have requested is not allowed."

EMERGENCY INSTALL (karena login sedang terkunci):
1. Backup:
   application/views/login/auth.php
   application/views/login/authanggota.php
2. Copy isi FILES/ ke root aplikasi dan overwrite dua file tersebut.
3. Hapus cookie localhost/caleg atau lakukan hard refresh jika perlu.
4. Buka ulang /caleg/Auth dan login.
5. Setelah login berhasil, simpan/rekam patch 007 melalui Deployment Safety Center agar histori deployment tetap berurutan.

JANGAN mematikan csrf_protection sebagai solusi permanen.
