<?php
declare(strict_types=1);

@set_time_limit(180);
@ini_set('memory_limit','256M');
@ini_set('display_errors','0');

const ACCESS_KEY = 'nmh11sG5pKNyfwnHQUGnsCNE';
const MAX_FILES = 100000;

if (!isset($_GET['key']) || !hash_equals(ACCESS_KEY, (string)$_GET['key'])) {
    http_response_code(403);
    exit('403 Forbidden');
}

$root = '/home/u278918108/domains/mydokumen.space/public_html/RujUxYuks';
$real = realpath($root);
if (!$real || !is_dir($real)) {
    http_response_code(500);
    exit('RujUxYuks not found');
}

$dangerExt = [
    'php','php3','php4','php5','php7','php8','phtml','phar','cgi','pl','py','sh',
    'bash','exe','dll','so','bin','com','scr','htaccess'
];

$counts = [];
$suspicious = [];
$files = 0;
$errors = [];

try {
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($real, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::LEAVES_ONLY
    );

    foreach ($it as $f) {
        if (!$f->isFile()) continue;
        $files++;
        if ($files > MAX_FILES) {
            $errors[] = 'file_limit_reached';
            break;
        }

        $path = $f->getPathname();
        $name = $f->getFilename();
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        if ($name === '.htaccess') $ext = 'htaccess';
        if ($ext === '') $ext = '[no_ext]';
        $counts[$ext] = ($counts[$ext] ?? 0) + 1;

        $isDanger = in_array($ext, $dangerExt, true);
        $isHidden = str_starts_with($name, '.');

        if ($isDanger || $isHidden) {
            $hash = @hash_file('sha256', $path);
            $suspicious[] = [
                'path' => $path,
                'size' => @filesize($path),
                'mtime' => @date('Y-m-d H:i:s O', @filemtime($path)),
                'ext' => $ext,
                'sha256' => $hash ?: 'HASH_ERROR'
            ];
        }
    }
} catch (Throwable $e) {
    $errors[] = get_class($e) . ': ' . $e->getMessage();
}

ksort($counts);

$txt = "PHASE 2B - RUJUXYUKS PUBLIC ASSET AUDIT\n";
$txt .= "ROOT: $real\n";
$txt .= "FILES SEEN: $files\n";
$txt .= "SUSPICIOUS/EXECUTABLE: " . count($suspicious) . "\n";
$txt .= "ERRORS: " . ($errors ? implode(' | ', $errors) : 'NONE') . "\n";
$txt .= str_repeat('=', 78) . "\n\n";
$txt .= "EXTENSION COUNTS\n";
$txt .= str_repeat('-', 78) . "\n";
foreach ($counts as $ext => $n) {
    $txt .= str_pad($ext, 16) . " : $n\n";
}
$txt .= "\nSUSPICIOUS / EXECUTABLE FILES\n";
$txt .= str_repeat('-', 78) . "\n";
foreach ($suspicious as $s) {
    $txt .= "PATH: {$s['path']}\n";
    $txt .= "EXT: {$s['ext']}\n";
    $txt .= "SIZE: {$s['size']}\n";
    $txt .= "MTIME: {$s['mtime']}\n";
    $txt .= "SHA256: {$s['sha256']}\n";
    $txt .= str_repeat('-', 78) . "\n";
}

if (isset($_GET['download'])) {
    header('Content-Type: text/plain; charset=UTF-8');
    header('Content-Disposition: attachment; filename="PHASE2B_RUJUxYUKS_AUDIT_' . date('Ymd_His') . '.txt"');
    echo $txt;
    exit;
}
?>
<!doctype html>
<html><head><meta charset="utf-8"><title>Phase 2B RujUxYuks Audit</title>
<style>
body{font-family:Arial,sans-serif;background:#f6f7f9;margin:25px}
.card{background:white;padding:20px;border:1px solid #ddd;border-radius:8px}
table{border-collapse:collapse;width:100%;font-size:13px}
th,td{border:1px solid #ddd;padding:7px;text-align:left}
th{background:#f0f0f0}
.bad{color:#b42318;font-weight:bold} .ok{color:#137333;font-weight:bold}
a.btn{display:inline-block;padding:8px 12px;border:1px solid #777;border-radius:5px;text-decoration:none;color:#222;margin:6px 0}
</style></head><body><div class="card">
<h2>Phase 2B — Audit RujUxYuks</h2>
<p>Files seen: <b><?=htmlspecialchars((string)$files)?></b></p>
<p>Suspicious / executable:
<b class="<?=count($suspicious)?'bad':'ok'?>"><?=count($suspicious)?></b></p>
<p>Errors: <?=htmlspecialchars($errors ? implode(' | ', $errors) : 'NONE')?></p>
<a class="btn" href="?key=<?=urlencode(ACCESS_KEY)?>&download=1">Download TXT Report</a>
<h3>Extension Counts</h3>
<table><tr><th>Extension</th><th>Count</th></tr>
<?php foreach($counts as $ext=>$n): ?>
<tr><td><?=htmlspecialchars($ext)?></td><td><?=$n?></td></tr>
<?php endforeach; ?></table>

<h3>Suspicious / Executable Files</h3>
<table><tr><th>Path</th><th>Ext</th><th>Size</th><th>SHA256</th></tr>
<?php foreach($suspicious as $s): ?>
<tr><td><?=htmlspecialchars($s['path'])?></td><td><?=htmlspecialchars($s['ext'])?></td>
<td><?=htmlspecialchars((string)$s['size'])?></td><td><?=htmlspecialchars($s['sha256'])?></td></tr>
<?php endforeach; ?></table>
</div></body></html>
