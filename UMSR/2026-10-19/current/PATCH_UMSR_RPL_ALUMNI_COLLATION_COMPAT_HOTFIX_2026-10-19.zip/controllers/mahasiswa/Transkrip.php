<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Transkrip extends CI_Controller
{
    private $edom_mulai_periode = '20252';

    public function __construct()
    {
        parent::__construct();

        if ($this->session->userdata('status_mahasiswa') != 'A' && $this->session->userdata('status_mahasiswa') != 'L') {
            $this->session->set_flashdata('gagal', 'Anda Belum Login!');
            redirect(base_url('Authmhs'));
        }
    }

    private function _check_edom()
    {
        $nim = (string) $this->session->userdata('nim');

        $belum_diisi = $this->db->query(
            "SELECT k.periode_krs
             FROM krsnilaikhs k
             LEFT JOIN hasil_qusioner h
                ON h.nim = k.nim
               AND h.periode = k.periode_krs
               AND h.id_jadwal = k.id_jadwal
             WHERE k.nim = ?
               AND k.periode_krs >= ?
               AND k.kode_nilai != 'K'
               AND k.kode_nilai != ''
               AND h.id_jadwal IS NULL
             GROUP BY k.periode_krs
             ORDER BY k.periode_krs ASC
             LIMIT 1",
            [$nim, $this->edom_mulai_periode]
        )->row_array();

        if (!empty($belum_diisi['periode_krs'])) {
            $periode = $belum_diisi['periode_krs'];
            $this->session->set_flashdata(
                'validasi',
                "Perhatian! Anda wajib mengisi Kuisioner Evaluasi Dosen (EDOM) untuk mata kuliah di periode {$periode} terlebih dahulu."
            );
            redirect('mahasiswa/Kuisioner/index/' . rawurlencode($periode));
        }
    }

    private function _get_mahasiswa($id_mhs)
    {
        return $this->db->query(
            "SELECT
                m.id,
                m.nim,
                m.nama,
                m.status,
                m.status_mahasiswa,
                m.jenis_kelamin,
                m.new_foto,
                p.nama_prodi,
                d.nidn,
                d.nama AS nama_dosen,
                d.gelar_depan,
                d.gelar_belakang
             FROM mahasiswa m
             LEFT JOIN prodi p ON m.kode_prodi = p.kode_prodi
             LEFT JOIN dosen d ON m.kode_penasehat = d.kode_penasehat
             WHERE m.id = ?
             LIMIT 1",
            [(int) $id_mhs]
        )->row_array();
    }

    private function _get_transkrip($nim)
    {
        $sql = "SELECT
                    mk.kode_matakuliah,
                    mk.nama_matakuliah,
                    mk.sks,
                    MAX(bn.nilai) AS nilai_terbaik,
                    (
                        SELECT k2.kode_nilai
                        FROM krsnilaikhs k2
                        INNER JOIN bobot_nilai b2 ON k2.kode_nilai = b2.kode_nilai
                        WHERE k2.kode_matakuliah = mk.kode_matakuliah
                          AND k2.nim = ?
                          AND k2.kode_nilai != 'K'
                        ORDER BY b2.nilai DESC, k2.periode_krs DESC
                        LIMIT 1
                    ) AS huruf_terbaik
                FROM krsnilaikhs kn
                INNER JOIN matakuliah mk ON kn.kode_matakuliah = mk.kode_matakuliah
                INNER JOIN bobot_nilai bn ON kn.kode_nilai = bn.kode_nilai
                WHERE kn.nim = ?
                  AND kn.kode_nilai != 'K'
                GROUP BY mk.kode_matakuliah, mk.nama_matakuliah, mk.sks
                ORDER BY mk.kode_matakuliah ASC";

        $regular = $this->db->query($sql, [(string) $nim, (string) $nim])->result_array();

        // Hasil RPL yang sudah difinalkan pengelola dan diposting menjadi bagian
        // histori akademik/transkrip, tanpa membuat KRS/jadwal fiktif.
        if (!$this->db->table_exists('rpl_pengajuan') || !$this->db->table_exists('rpl_rekognisi_mk')) {
            return $regular;
        }

        $rpl = $this->db->query(
            "SELECT rm.kode_matakuliah, rm.nama_matakuliah, rm.sks,
                    bn.nilai AS nilai_terbaik, rm.nilai_huruf_final AS huruf_terbaik
             FROM rpl_rekognisi_mk rm
             INNER JOIN rpl_pengajuan rp ON rp.id = rm.id_pengajuan
             LEFT JOIN bobot_nilai bn ON CONVERT(bn.kode_nilai USING utf8mb4) COLLATE utf8mb4_general_ci = CONVERT(rm.nilai_huruf_final USING utf8mb4) COLLATE utf8mb4_general_ci
             WHERE rp.nim = ?
               AND rm.keputusan = 'DIAKUI'
               AND rm.dipilih_mahasiswa = 1
               AND rm.final_pengelola = 1
               AND rm.posted_at IS NOT NULL
             ORDER BY rm.kode_matakuliah ASC",
            [(string) $nim]
        )->result_array();

        $merged = [];
        foreach ($regular as $row) {
            $merged[(string) $row['kode_matakuliah']] = $row;
        }
        foreach ($rpl as $row) {
            $code = (string) $row['kode_matakuliah'];
            if (!isset($merged[$code]) || (float) ($row['nilai_terbaik'] ?? 0) > (float) ($merged[$code]['nilai_terbaik'] ?? 0)) {
                $merged[$code] = $row;
            }
        }
        ksort($merged, SORT_NATURAL);
        return array_values($merged);
    }

    private function _get_tren_ips($nim)
    {
        return $this->db->query(
            "SELECT
                kn.periode_krs,
                SUM(mk.sks) AS total_sks,
                SUM(mk.sks * bn.nilai) AS total_mutu,
                (SUM(mk.sks * bn.nilai) / NULLIF(SUM(mk.sks), 0)) AS ips
             FROM krsnilaikhs kn
             INNER JOIN matakuliah mk ON kn.kode_matakuliah = mk.kode_matakuliah
             INNER JOIN bobot_nilai bn ON kn.kode_nilai = bn.kode_nilai
             WHERE kn.nim = ?
               AND kn.kode_nilai != 'K'
             GROUP BY kn.periode_krs
             ORDER BY kn.periode_krs ASC",
            [(string) $nim]
        )->result_array();
    }

    private function _get_target_sks($jenjang)
    {
        $wisuda = $this->db->query(
            "SELECT batas_sks, sks_1, sks_2, sks_3
             FROM periode_wisuda
             WHERE is_active = 'Y'
             ORDER BY id_periode_wisuda DESC
             LIMIT 1"
        )->row_array();

        if (empty($wisuda)) {
            return 0;
        }

        switch (strtoupper((string) $jenjang)) {
            case 'S1-R':
                return (float) (!empty($wisuda['sks_1']) ? $wisuda['sks_1'] : $wisuda['batas_sks']);
            case 'S2-R':
                return (float) (!empty($wisuda['sks_2']) ? $wisuda['sks_2'] : $wisuda['batas_sks']);
            case 'S3-R':
                return (float) (!empty($wisuda['sks_3']) ? $wisuda['sks_3'] : $wisuda['batas_sks']);
            default:
                return (float) ($wisuda['batas_sks'] ?? 0);
        }
    }

    private function _build_rekap($transkrip)
    {
        $total_sks = 0;
        $total_mutu = 0;

        foreach ($transkrip as $row) {
            $sks = (float) $row['sks'];
            $nilai = (float) $row['nilai_terbaik'];
            $total_sks += $sks;
            $total_mutu += ($sks * $nilai);
        }

        return [
            'total_mk' => count($transkrip),
            'total_sks' => $total_sks,
            'total_mutu' => $total_mutu,
            'ipk' => $total_sks > 0 ? ($total_mutu / $total_sks) : 0,
        ];
    }

    public function index()
    {
        $this->_check_edom();

        $id_mhs = (int) $this->session->userdata('id');
        $nim = (string) $this->session->userdata('nim');

        $data['judul'] = 'Transkrip Nilai Akademik';
        $data['mahasiswa'] = $this->_get_mahasiswa($id_mhs);
        $data['menu_mahasiswa'] = [
            'status_mahasiswa' => $data['mahasiswa']['status_mahasiswa'] ?? '',
            'jenis_kelamin' => $data['mahasiswa']['jenis_kelamin'] ?? 'L',
            'new_foto' => $data['mahasiswa']['new_foto'] ?? '',
        ];

        $data['transkrip'] = $this->_get_transkrip($nim);
        $data['tren_ips'] = $this->_get_tren_ips($nim);
        $data['rekap'] = $this->_build_rekap($data['transkrip']);
        $data['target_sks'] = $this->_get_target_sks($data['mahasiswa']['status'] ?? '');
        $data['persentase_sks'] = $data['target_sks'] > 0
            ? min(100, ($data['rekap']['total_sks'] / $data['target_sks']) * 100)
            : 0;

        $this->load->view('templates/headermhs', $data);
        $this->load->view('templates/menumhs', $data);
        $this->load->view('mahasiswa/transkrip/view', $data);
        $this->load->view('templates/footermhs');
    }

    public function cetak_pdf()
    {
        $this->_check_edom();

        $id_mhs = (int) $this->session->userdata('id');
        $nim = (string) $this->session->userdata('nim');

        $data['mahasiswa'] = $this->_get_mahasiswa($id_mhs);
        $data['transkrip'] = $this->_get_transkrip($nim);
        $data['rekap'] = $this->_build_rekap($data['transkrip']);

        $this->load->view('mahasiswa/transkrip/cetak', $data);
    }
}
