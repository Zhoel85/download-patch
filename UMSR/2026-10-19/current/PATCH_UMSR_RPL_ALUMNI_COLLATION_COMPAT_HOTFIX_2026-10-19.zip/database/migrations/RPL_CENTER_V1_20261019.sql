-- UMSR RPL CENTER V1 - 2026-10-19
-- Idempotent migration. Run once before opening RPL Center.
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS `rpl_pengajuan` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nim` VARCHAR(30) NOT NULL,
  `kode_prodi` VARCHAR(30) NOT NULL,
  `jenis_rpl` ENUM('RPL_PEROLEHAN','RPL_TRANSFER') NOT NULL DEFAULT 'RPL_PEROLEHAN',
  `status` VARCHAR(40) NOT NULL DEFAULT 'MENUNGGU_BIODATA',
  `periode_masuk` VARCHAR(10) DEFAULT NULL,
  `status_pekerjaan` VARCHAR(30) DEFAULT NULL,
  `nama_instansi` VARCHAR(180) DEFAULT NULL,
  `jabatan_pekerjaan` VARCHAR(180) DEFAULT NULL,
  `nama_atasan` VARCHAR(180) DEFAULT NULL,
  `jabatan_atasan` VARCHAR(180) DEFAULT NULL,
  `alamat_instansi` VARCHAR(255) DEFAULT NULL,
  `biodata_lengkap` TINYINT(1) NOT NULL DEFAULT 0,
  `berkas_lengkap` TINYINT(1) NOT NULL DEFAULT 0,
  `evaluasi_diri_lengkap` TINYINT(1) NOT NULL DEFAULT 0,
  `submitted_at` DATETIME DEFAULT NULL,
  `verified_at` DATETIME DEFAULT NULL,
  `verified_by_dosen` BIGINT DEFAULT NULL,
  `finalized_at` DATETIME DEFAULT NULL,
  `posted_at` DATETIME DEFAULT NULL,
  `activated_at` DATETIME DEFAULT NULL,
  `siera_status` VARCHAR(30) NOT NULL DEFAULT 'BELUM_SIAP',
  `siera_registered_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL,
  `updated_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rpl_pengajuan_nim` (`nim`),
  KEY `idx_rpl_pengajuan_prodi_status` (`kode_prodi`,`status`),
  KEY `idx_rpl_pengajuan_siera` (`siera_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `rpl_pengelola` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `kode_prodi` VARCHAR(30) NOT NULL,
  `id_dosen` BIGINT NOT NULL,
  `aktif` TINYINT(1) NOT NULL DEFAULT 1,
  `ditetapkan_oleh_tipe` VARCHAR(20) NOT NULL DEFAULT 'ADMIN',
  `ditetapkan_oleh_id` BIGINT DEFAULT NULL,
  `created_at` DATETIME NOT NULL,
  `updated_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rpl_pengelola` (`kode_prodi`,`id_dosen`),
  KEY `idx_rpl_pengelola_dosen` (`id_dosen`,`aktif`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `rpl_master_berkas` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `kode` VARCHAR(60) NOT NULL,
  `nama` VARCHAR(160) NOT NULL,
  `kategori` VARCHAR(40) NOT NULL DEFAULT 'ADMINISTRATIF',
  `wajib` TINYINT(1) NOT NULL DEFAULT 1,
  `untuk_bekerja` TINYINT(1) NOT NULL DEFAULT 0,
  `aktif` TINYINT(1) NOT NULL DEFAULT 1,
  `urutan` INT NOT NULL DEFAULT 0,
  `keterangan` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rpl_master_berkas_kode` (`kode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT IGNORE INTO `rpl_master_berkas` (`kode`,`nama`,`kategori`,`wajib`,`untuk_bekerja`,`aktif`,`urutan`,`keterangan`) VALUES
('IJAZAH','Ijazah Pendidikan Terakhir','ADMINISTRATIF',1,0,1,10,'Dokumen pendidikan formal terakhir'),
('TRANSKRIP','Transkrip Nilai','ADMINISTRATIF',1,0,1,20,'Transkrip pendidikan formal sebelumnya'),
('CV_RPL_TTD','Daftar Riwayat Hidup RPL Bertanda Tangan','FORMULIR',1,0,1,30,'Cetak dari portal, tanda tangani, lalu unggah'),
('FORM_APLIKASI_TTD','Formulir Aplikasi RPL Bertanda Tangan','FORMULIR',1,0,1,40,'Cetak dari portal, tanda tangani, lalu unggah'),
('FED_TTD','Formulir Evaluasi Diri (FED) Bertanda Tangan','FORMULIR',1,0,1,45,'Isi evaluasi diri, cetak dari portal, tanda tangani, lalu unggah'),
('SURAT_IZIN_ATASAN','Surat Izin/Persetujuan Atasan','FORMULIR',0,1,1,50,'Wajib bagi mahasiswa yang bekerja; ASN mengikuti pejabat pembina kepegawaian, non-ASN atasan langsung'),
('RIWAYAT_PEKERJAAN','Bukti Riwayat/Pengalaman Pekerjaan','EVIDENCE',0,0,1,60,'Surat kerja, uraian tugas, referensi atau bukti sejenis'),
('SERTIFIKAT_KOMPETENSI','Sertifikat Kompetensi','EVIDENCE',0,0,1,70,'Sertifikat kompetensi yang relevan'),
('LISENSI_PROFESI','Sertifikat/Lisensi Profesi','EVIDENCE',0,0,1,80,'Lisensi atau sertifikat profesi'),
('PELATIHAN','Sertifikat Pelatihan','EVIDENCE',0,0,1,90,'Sertakan materi dan durasi bila tersedia'),
('PORTOFOLIO','Portofolio / Bukti Kegiatan / Karya','EVIDENCE',0,0,1,100,'Karya, kegiatan, proyek, dokumentasi atau bukti relevan'),
('REFERENSI','Referensi Pemberi Kerja / Supervisor','EVIDENCE',0,0,1,110,'Surat referensi/verifikasi pihak ketiga'),
('PENILAIAN_KINERJA','Penilaian Kinerja','EVIDENCE',0,0,1,120,'Penilaian kinerja dari institusi/perusahaan'),
('KEANGGOTAAN_PROFESI','Keanggotaan Asosiasi Profesi','EVIDENCE',0,0,1,130,'Kartu/sertifikat keanggotaan profesi'),
('PENGHARGAAN','Penghargaan Industri/Profesi','EVIDENCE',0,0,1,140,'Penghargaan yang relevan'),
('DOKUMEN_LAIN','Dokumen Pendukung Lain','EVIDENCE',0,0,1,150,'Dokumen relevan lain');

CREATE TABLE IF NOT EXISTS `rpl_berkas` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_pengajuan` BIGINT UNSIGNED NOT NULL,
  `id_master_berkas` BIGINT UNSIGNED NOT NULL,
  `judul` VARCHAR(180) DEFAULT NULL,
  `penerbit_instansi` VARCHAR(180) DEFAULT NULL,
  `nomor_dokumen` VARCHAR(120) DEFAULT NULL,
  `tanggal_dokumen` DATE DEFAULT NULL,
  `durasi` VARCHAR(100) DEFAULT NULL,
  `deskripsi` TEXT DEFAULT NULL,
  `file_path` VARCHAR(255) NOT NULL,
  `nama_file_asli` VARCHAR(255) NOT NULL,
  `mime_type` VARCHAR(120) DEFAULT NULL,
  `ukuran` BIGINT NOT NULL DEFAULT 0,
  `status_verifikasi` ENUM('MENUNGGU','VALID','PERLU_PERBAIKAN','DITOLAK') NOT NULL DEFAULT 'MENUNGGU',
  `catatan_verifikasi` VARCHAR(500) DEFAULT NULL,
  `verified_by_dosen` BIGINT DEFAULT NULL,
  `verified_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL,
  `updated_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rpl_berkas_pengajuan` (`id_pengajuan`,`status_verifikasi`),
  KEY `idx_rpl_berkas_master` (`id_master_berkas`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `rpl_evaluasi_diri` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_pengajuan` BIGINT UNSIGNED NOT NULL,
  `kompetensi` TEXT NOT NULL,
  `tingkat` ENUM('SANGAT_BAIK','BAIK','TIDAK_PERNAH') NOT NULL DEFAULT 'BAIK',
  `id_berkas` BIGINT UNSIGNED DEFAULT NULL,
  `keterangan` TEXT DEFAULT NULL,
  `created_at` DATETIME NOT NULL,
  `updated_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rpl_eval_pengajuan` (`id_pengajuan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `rpl_asesor` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_pengajuan` BIGINT UNSIGNED NOT NULL,
  `id_dosen` BIGINT NOT NULL,
  `peran` ENUM('UTAMA','PENDAMPING') NOT NULL DEFAULT 'UTAMA',
  `status` ENUM('DITUGASKAN','PROSES','SELESAI') NOT NULL DEFAULT 'DITUGASKAN',
  `ditetapkan_oleh_tipe` VARCHAR(20) NOT NULL DEFAULT 'PENGELOLA',
  `ditetapkan_oleh_id` BIGINT DEFAULT NULL,
  `finalized_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL,
  `updated_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rpl_asesor` (`id_pengajuan`,`id_dosen`),
  KEY `idx_rpl_asesor_dosen` (`id_dosen`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `rpl_wawancara` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_pengajuan` BIGINT UNSIGNED NOT NULL,
  `tanggal` DATE NOT NULL,
  `jam` TIME NOT NULL,
  `metode` ENUM('OFFLINE','ONLINE') NOT NULL DEFAULT 'OFFLINE',
  `lokasi_link` VARCHAR(255) DEFAULT NULL,
  `catatan_jadwal` VARCHAR(500) DEFAULT NULL,
  `terlaksana` TINYINT(1) NOT NULL DEFAULT 0,
  `ringkasan_wawancara` TEXT DEFAULT NULL,
  `catatan_asesor` TEXT DEFAULT NULL,
  `updated_by_dosen` BIGINT DEFAULT NULL,
  `created_at` DATETIME NOT NULL,
  `updated_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rpl_wawancara_pengajuan` (`id_pengajuan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `rpl_rekognisi_mk` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_pengajuan` BIGINT UNSIGNED NOT NULL,
  `id_asesor` BIGINT UNSIGNED NOT NULL,
  `kode_matakuliah` VARCHAR(50) NOT NULL,
  `nama_matakuliah` VARCHAR(180) NOT NULL,
  `sks` DECIMAL(5,2) NOT NULL DEFAULT 0,
  `semester` VARCHAR(10) DEFAULT NULL,
  `keputusan` ENUM('DIAKUI','TIDAK_DIAKUI','ASESMEN_TAMBAHAN') NOT NULL DEFAULT 'TIDAK_DIAKUI',
  `nilai_angka` DECIMAL(5,2) DEFAULT NULL,
  `nilai_huruf` VARCHAR(5) DEFAULT NULL,
  `dasar_bukti` TEXT DEFAULT NULL,
  `catatan_asesor` TEXT DEFAULT NULL,
  `dipilih_mahasiswa` TINYINT(1) NOT NULL DEFAULT 0,
  `nilai_final` DECIMAL(5,2) DEFAULT NULL,
  `nilai_huruf_final` VARCHAR(5) DEFAULT NULL,
  `final_pengelola` TINYINT(1) NOT NULL DEFAULT 0,
  `posted_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL,
  `updated_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rpl_rekognisi_asesor_mk` (`id_pengajuan`,`id_asesor`,`kode_matakuliah`),
  KEY `idx_rpl_rekognisi_final` (`id_pengajuan`,`dipilih_mahasiswa`,`final_pengelola`,`posted_at`),
  KEY `idx_rpl_rekognisi_mk` (`kode_matakuliah`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `rpl_log` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_pengajuan` BIGINT UNSIGNED DEFAULT NULL,
  `aktor_tipe` VARCHAR(30) NOT NULL,
  `aktor_id` VARCHAR(50) DEFAULT NULL,
  `aksi` VARCHAR(80) NOT NULL,
  `keterangan` TEXT DEFAULT NULL,
  `ip_address` VARCHAR(64) DEFAULT NULL,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rpl_log_pengajuan` (`id_pengajuan`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
