SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS `alumni_profile` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nim` VARCHAR(30) NOT NULL,
  `email_pribadi` VARCHAR(150) DEFAULT NULL,
  `hp_wa` VARCHAR(30) DEFAULT NULL,
  `alamat_domisili` TEXT DEFAULT NULL,
  `kode_negara` VARCHAR(10) DEFAULT 'ID',
  `provinsi` VARCHAR(100) DEFAULT NULL,
  `kabupaten_kota` VARCHAR(100) DEFAULT NULL,
  `kode_pos` VARCHAR(10) DEFAULT NULL,
  `linkedin` VARCHAR(255) DEFAULT NULL,
  `instagram` VARCHAR(255) DEFAULT NULL,
  `website` VARCHAR(255) DEFAULT NULL,
  `status_aktivitas` VARCHAR(30) DEFAULT NULL,
  `profil_publik` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL,
  `updated_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_alumni_profile_nim` (`nim`),
  KEY `idx_alumni_status_aktivitas` (`status_aktivitas`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `alumni_karier` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nim` VARCHAR(30) NOT NULL,
  `jenis_aktivitas` VARCHAR(30) NOT NULL DEFAULT 'BEKERJA',
  `nama_instansi_usaha` VARCHAR(180) DEFAULT NULL,
  `jabatan_peran` VARCHAR(150) DEFAULT NULL,
  `bidang` VARCHAR(180) DEFAULT NULL,
  `jenis_instansi` VARCHAR(80) DEFAULT NULL,
  `tanggal_mulai` DATE DEFAULT NULL,
  `tanggal_selesai` DATE DEFAULT NULL,
  `masih_aktif` TINYINT(1) NOT NULL DEFAULT 1,
  `provinsi` VARCHAR(100) DEFAULT NULL,
  `kabupaten_kota` VARCHAR(100) DEFAULT NULL,
  `negara` VARCHAR(100) DEFAULT 'Indonesia',
  `rentang_penghasilan` VARCHAR(80) DEFAULT NULL,
  `jumlah_pegawai` INT DEFAULT NULL,
  `keterangan` TEXT DEFAULT NULL,
  `created_at` DATETIME NOT NULL,
  `updated_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_alumni_karier_nim` (`nim`),
  KEY `idx_alumni_karier_aktif` (`nim`,`masih_aktif`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `alumni_pendidikan_lanjut` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nim` VARCHAR(30) NOT NULL,
  `perguruan_tinggi` VARCHAR(180) NOT NULL,
  `program_studi` VARCHAR(180) DEFAULT NULL,
  `jenjang` VARCHAR(30) DEFAULT NULL,
  `negara` VARCHAR(100) DEFAULT 'Indonesia',
  `tahun_mulai` VARCHAR(4) DEFAULT NULL,
  `tahun_selesai` VARCHAR(4) DEFAULT NULL,
  `sumber_pembiayaan` VARCHAR(100) DEFAULT NULL,
  `masih_aktif` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL,
  `updated_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_alumni_pendidikan_nim` (`nim`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `tracer_periode` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nama` VARCHAR(150) NOT NULL,
  `tahun_pelaporan` VARCHAR(4) NOT NULL,
  `target_tahun_lulus` VARCHAR(4) NOT NULL,
  `tanggal_mulai` DATE NOT NULL,
  `tanggal_selesai` DATE NOT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'DRAFT',
  `sptjm_file` VARCHAR(255) DEFAULT NULL,
  `sptjm_uploaded_at` DATETIME DEFAULT NULL,
  `created_by_tipe` VARCHAR(20) DEFAULT NULL,
  `created_by_id` VARCHAR(50) DEFAULT NULL,
  `created_at` DATETIME NOT NULL,
  `updated_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tracer_periode_status` (`status`),
  KEY `idx_tracer_periode_target` (`target_tahun_lulus`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `tracer_responden` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_periode` BIGINT UNSIGNED NOT NULL,
  `nim` VARCHAR(30) NOT NULL,
  `status` VARCHAR(30) NOT NULL DEFAULT 'BELUM_MENGISI',
  `progress` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `metode_pengisian` VARCHAR(20) NOT NULL DEFAULT 'SELF',
  `diisi_oleh_tipe` VARCHAR(20) DEFAULT NULL,
  `diisi_oleh_id` VARCHAR(50) DEFAULT NULL,
  `submitted_at` DATETIME DEFAULT NULL,
  `verified_at` DATETIME DEFAULT NULL,
  `approved_at` DATETIME DEFAULT NULL,
  `pddikti_status` VARCHAR(30) NOT NULL DEFAULT 'BELUM_SIAP',
  `catatan_pengelola` TEXT DEFAULT NULL,
  `created_at` DATETIME NOT NULL,
  `updated_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tracer_responden` (`id_periode`,`nim`),
  KEY `idx_tracer_responden_status` (`status`),
  KEY `idx_tracer_responden_nim` (`nim`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `tracer_jawaban` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_responden` BIGINT UNSIGNED NOT NULL,
  `email_aktif` VARCHAR(150) DEFAULT NULL,
  `hp_aktif` VARCHAR(30) DEFAULT NULL,
  `npwp` VARCHAR(30) DEFAULT NULL,
  `status_aktivitas` VARCHAR(30) DEFAULT NULL,
  `sumber_dana_kuliah` VARCHAR(100) DEFAULT NULL,
  `nama_instansi_usaha` VARCHAR(180) DEFAULT NULL,
  `jabatan_peran` VARCHAR(150) DEFAULT NULL,
  `bidang_aktivitas` VARCHAR(180) DEFAULT NULL,
  `jenis_instansi` VARCHAR(100) DEFAULT NULL,
  `tanggal_mulai_aktivitas` DATE DEFAULT NULL,
  `provinsi_aktivitas` VARCHAR(100) DEFAULT NULL,
  `kabkota_aktivitas` VARCHAR(100) DEFAULT NULL,
  `negara_aktivitas` VARCHAR(100) DEFAULT 'Indonesia',
  `rentang_penghasilan` VARCHAR(80) DEFAULT NULL,
  `cara_memperoleh_pekerjaan` VARCHAR(180) DEFAULT NULL,
  `keselarasan_horizontal` VARCHAR(50) DEFAULT NULL,
  `keselarasan_vertikal` VARCHAR(50) DEFAULT NULL,
  `perguruan_tinggi_lanjut` VARCHAR(180) DEFAULT NULL,
  `prodi_lanjut` VARCHAR(180) DEFAULT NULL,
  `jenjang_lanjut` VARCHAR(30) DEFAULT NULL,
  `negara_lanjut` VARCHAR(100) DEFAULT NULL,
  `tahun_mulai_lanjut` VARCHAR(4) DEFAULT NULL,
  `status_pencarian_kerja` TEXT DEFAULT NULL,
  `alasan_belum_bekerja` TEXT DEFAULT NULL,
  `kompetensi_saat_lulus_json` LONGTEXT DEFAULT NULL,
  `kompetensi_dibutuhkan_json` LONGTEXT DEFAULT NULL,
  `pembelajaran_json` LONGTEXT DEFAULT NULL,
  `jawaban_tambahan_json` LONGTEXT DEFAULT NULL,
  `created_at` DATETIME NOT NULL,
  `updated_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tracer_jawaban_responden` (`id_responden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `tracer_log` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_periode` BIGINT UNSIGNED DEFAULT NULL,
  `id_responden` BIGINT UNSIGNED DEFAULT NULL,
  `nim` VARCHAR(30) DEFAULT NULL,
  `aktor_tipe` VARCHAR(20) NOT NULL,
  `aktor_id` VARCHAR(50) DEFAULT NULL,
  `aksi` VARCHAR(80) NOT NULL,
  `keterangan` TEXT DEFAULT NULL,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tracer_log_responden` (`id_responden`),
  KEY `idx_tracer_log_nim` (`nim`),
  KEY `idx_tracer_log_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

SET FOREIGN_KEY_CHECKS=1;
