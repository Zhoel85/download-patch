<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<?php
$rows = is_array($rows ?? null) ? $rows : array();
$filters = is_array($filters ?? null) ? $filters : array();
$options = is_array($options ?? null) ? $options : array();
$pagination = is_array($pagination ?? null) ? $pagination : array();
$auditRows = is_array($audit_rows ?? null) ? $audit_rows : array();
$activeTab = in_array(($active_tab ?? 'data'), array('data', 'repair', 'sql', 'audit'), true) ? $active_tab : 'data';
$repairCandidates = is_array($repair_candidates ?? null) ? $repair_candidates : array();
$returnQuery = http_build_query($_GET);
$csrfName = $this->security->get_csrf_token_name();
$csrfHash = $this->security->get_csrf_hash();

if (!function_exists('cdk_status_mhs_label')) {
    function cdk_status_mhs_label($status)
    {
        $status = strtoupper(trim((string) $status));
        $map = array('A' => 'Aktif', 'L' => 'Lulus', 'N' => 'Nonaktif');
        return $map[$status] ?? ($status !== '' ? $status : 'Tidak ditemukan');
    }
}

if (!function_exists('cdk_status_mhs_class')) {
    function cdk_status_mhs_class($status)
    {
        $status = strtoupper(trim((string) $status));
        if ($status === 'A') return 'success';
        if ($status === 'L') return 'primary';
        if ($status === 'N') return 'secondary';
        return 'warning';
    }
}

if (!function_exists('cdk_status_code_class')) {
    function cdk_status_code_class($code)
    {
        return (int) $code === 200 ? 'success' : ((int) $code === 0 ? 'secondary' : 'warning');
    }
}

if (!function_exists('cdk_status_code_label')) {
    function cdk_status_code_label($code, $transactionStatus = '')
    {
        if ((int) $code === 200) return 'Lunas';
        $transactionStatus = trim((string) $transactionStatus);
        return $transactionStatus !== '' ? $transactionStatus : 'Status ' . (int) $code;
    }
}

if (!function_exists('cdk_money')) {
    function cdk_money($value)
    {
        return 'Rp ' . number_format((float) $value, 0, ',', '.');
    }
}

$queryBase = $_GET;
unset($queryBase['page']);

$tabUrl = function ($tab) use ($queryBase) {
    $q = $queryBase;
    $q['tab'] = $tab;
    return base_url('admin/Control_database_keuangan?' . http_build_query($q));
};

$flashSuccess = (string) $this->session->flashdata('sukses');
$flashError = (string) $this->session->flashdata('gagal');
?>

<style>
.cdk-page .card{border:1px solid rgba(67,89,113,.08);box-shadow:0 .125rem .5rem rgba(67,89,113,.06)}
.cdk-page .hero-icon{width:46px;height:46px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:24px;background:rgba(105,108,255,.12);color:#696cff;flex:0 0 auto}
.cdk-page .filter-card .form-label{display:block;font-size:.75rem;font-weight:600;line-height:1.2;color:#697a8d;margin:0 0 .4rem}
.cdk-page .filter-card .row{--bs-gutter-x:.75rem;--bs-gutter-y:1rem}
.cdk-page .filter-card .form-control,.cdk-page .filter-card .form-select{width:100%}
.cdk-page .table-wrap{overflow:auto;max-width:100%}
.cdk-page .data-table{min-width:1180px;margin-bottom:0}
.cdk-page .data-table>thead>tr>th{font-size:.72rem;letter-spacing:.02em;text-transform:uppercase;color:#697a8d;background:#f8f9fa;white-space:nowrap}
.cdk-page .data-table>:not(caption)>*>*{padding:.72rem .65rem;vertical-align:middle}
.cdk-page .student-name,.cdk-page .prodi-name{font-weight:700;color:#384551;line-height:1.25}
.cdk-page .subtext{font-size:.73rem;color:#8592a3;line-height:1.35}
.cdk-page .money-line{display:flex;align-items:center;justify-content:space-between;gap:12px;font-size:.75rem;white-space:nowrap}
.cdk-page .money-line strong{font-size:.78rem;color:#384551}
.cdk-page .bulk-bar{display:none;border:1px solid rgba(105,108,255,.18);background:rgba(105,108,255,.06);border-radius:12px;padding:.65rem .8rem}
.cdk-page .bulk-bar.is-active{display:flex}
.cdk-page .cdk-tab-header{padding:.9rem 1.25rem 0;background:#fff;border-bottom:1px solid #e9ecef}
.cdk-page .cdk-module-tabs{display:flex;flex-wrap:wrap;gap:.25rem;margin:0;border-bottom:0}
.cdk-page .cdk-module-tabs .nav-item{margin:0}
.cdk-page .cdk-module-tabs .nav-link{margin:0;padding:.72rem 1rem;border:0;border-radius:.5rem .5rem 0 0;font-weight:600;line-height:1.2;color:#566a7f;white-space:nowrap}
.cdk-page .cdk-module-tabs .nav-link:hover{color:#696cff;background:rgba(105,108,255,.05)}
.cdk-page .cdk-module-tabs .nav-link.active{color:#696cff;background:rgba(105,108,255,.08);box-shadow:inset 0 -2px 0 #696cff}
.cdk-page .cdk-tab-body{padding-top:0!important}
.cdk-page .cdk-filter-body{padding-bottom:1rem}
.cdk-page .cdk-tab-gap{display:block!important;height:18px!important;min-height:18px!important;flex:0 0 18px!important}
.cdk-page .filter-actions .btn{min-height:40px}
.cdk-page .pagination .page-link{min-width:34px;text-align:center}
.cdk-page .detail-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}
.cdk-page .detail-item{border:1px solid #e7e7ff;border-radius:10px;padding:.65rem .75rem;background:#fbfbff;min-width:0}
.cdk-page .detail-key{font-size:.67rem;color:#8592a3;text-transform:uppercase;letter-spacing:.03em;margin-bottom:.2rem}
.cdk-page .detail-value{font-size:.84rem;color:#384551;word-break:break-word;white-space:pre-wrap}
.cdk-page .sql-editor{font-family:Consolas,Monaco,monospace;min-height:190px;resize:vertical}
.cdk-page .sql-result{max-height:520px;overflow:auto}
.cdk-page .audit-json{max-height:260px;overflow:auto;font-size:.72rem;background:#f7f7fb;border-radius:8px;padding:.75rem;white-space:pre-wrap;word-break:break-word}
.cdk-page .modal-xl{--bs-modal-width:1180px}
.cdk-page .edit-section{border:1px solid #e9ecef;border-radius:12px;padding:1rem;height:100%}
.cdk-page .edit-section-title{font-weight:700;color:#566a7f;margin-bottom:.9rem}
.cdk-page .form-control,.cdk-page .form-select{min-height:40px}
@media(max-width:767.98px){.cdk-page .detail-grid{grid-template-columns:1fr}.cdk-page .hero-actions{width:100%}.cdk-page .hero-actions .btn{flex:1}.cdk-page .cdk-tab-header{padding:.75rem .75rem 0;overflow-x:auto}.cdk-page .cdk-module-tabs{flex-wrap:nowrap;width:max-content;min-width:100%}.cdk-page .cdk-module-tabs .nav-link{padding:.65rem .8rem}.cdk-page .cdk-tab-gap{height:14px!important;min-height:14px!important;flex-basis:14px!important}}
</style>

<div class="cdk-page">
    <div class="row g-4">
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-body d-flex flex-column flex-lg-row align-items-lg-center justify-content-between gap-3">
                    <div class="d-flex align-items-start gap-3">
                        <div class="hero-icon"><i class="bx bx-data"></i></div>
                        <div>
                            <div class="text-uppercase text-muted small fw-semibold mb-1">Sistem · Admin Super Only</div>
                            <h4 class="mb-1">Control Database Keuangan</h4>
                            <p class="text-muted mb-0">Kontrol langsung tabel <code>tagihan</code>: filter, edit, status, repair, hapus terpilih, SQL Console, dan audit perubahan.</p>
                        </div>
                    </div>
                    <div class="hero-actions d-flex flex-wrap gap-2">
                        <span class="badge bg-label-danger px-3 py-2"><i class="bx bx-lock-alt me-1"></i>id_user = 1</span>
                        <span class="badge bg-label-<?= !empty($audit_ready) ? 'success' : 'warning'; ?> px-3 py-2">Audit <?= !empty($audit_ready) ? 'Aktif' : 'Tidak Siap'; ?></span>
                    </div>
                </div>
            </div>
        </div>

        <?php if ($flashSuccess !== ''): ?>
            <div class="col-12"><div class="alert alert-success alert-dismissible fade show mb-0"><i class="bx bx-check-circle me-1"></i><?= html_escape($flashSuccess); ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div></div>
        <?php endif; ?>
        <?php if ($flashError !== ''): ?>
            <div class="col-12"><div class="alert alert-danger alert-dismissible fade show mb-0"><i class="bx bx-error-circle me-1"></i><?= html_escape($flashError); ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div></div>
        <?php endif; ?>

        <?php if (empty($table_ready)): ?>
            <div class="col-12"><div class="alert alert-danger"><strong>Tabel tagihan tidak ditemukan.</strong> Modul tidak menjalankan perubahan apa pun.</div></div>
        <?php else: ?>
            <div class="col-12">
                <div class="card">
                    <div class="card-header cdk-tab-header">
                        <ul class="nav nav-tabs cdk-module-tabs">
                            <li class="nav-item"><a class="nav-link <?= $activeTab === 'data' ? 'active' : ''; ?>" href="<?= html_escape($tabUrl('data')); ?>"><i class="bx bx-table me-1"></i>Data Tagihan</a></li>
                            <li class="nav-item"><a class="nav-link <?= $activeTab === 'repair' ? 'active' : ''; ?>" href="<?= html_escape($tabUrl('repair')); ?>"><i class="bx bx-wrench me-1"></i>Repair</a></li>
                            <li class="nav-item"><a class="nav-link <?= $activeTab === 'sql' ? 'active' : ''; ?>" href="<?= html_escape($tabUrl('sql')); ?>"><i class="bx bx-code-alt me-1"></i>SQL Console</a></li>
                            <li class="nav-item"><a class="nav-link <?= $activeTab === 'audit' ? 'active' : ''; ?>" href="<?= html_escape($tabUrl('audit')); ?>"><i class="bx bx-history me-1"></i>Audit Log</a></li>
                        </ul>
                    </div>

                    <?php if ($activeTab === 'data'): ?>
                        <div class="card-body cdk-tab-body cdk-filter-body">
                            <div class="cdk-tab-gap" aria-hidden="true"></div>
                            <form method="get" action="<?= base_url('admin/Control_database_keuangan'); ?>" class="filter-card">
                                <input type="hidden" name="tab" value="data">
                                <div class="row align-items-end">
                                    <div class="col-xl-2 col-md-4">
                                        <label class="form-label">Periode</label>
                                        <select name="period" class="form-select">
                                            <option value="">Semua Periode</option>
                                            <?php foreach (($options['periods'] ?? array()) as $value): ?><option value="<?= html_escape($value); ?>" <?= (string) ($filters['period'] ?? '') === (string) $value ? 'selected' : ''; ?>><?= html_escape($value); ?></option><?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="col-xl-2 col-md-4">
                                        <label class="form-label">Jenis Tagihan</label>
                                        <select name="jenistagihan" class="form-select">
                                            <option value="">Semua Jenis</option>
                                            <?php foreach (($options['types'] ?? array()) as $value): ?><option value="<?= html_escape($value); ?>" <?= (string) ($filters['jenistagihan'] ?? '') === (string) $value ? 'selected' : ''; ?>><?= html_escape($value); ?></option><?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="col-xl-2 col-md-4">
                                        <label class="form-label">Program Studi</label>
                                        <select name="kode_prodi" class="form-select">
                                            <option value="">Semua Prodi</option>
                                            <?php foreach (($options['prodi'] ?? array()) as $prodi): ?><option value="<?= html_escape($prodi['kode_prodi'] ?? ''); ?>" <?= (string) ($filters['kode_prodi'] ?? '') === (string) ($prodi['kode_prodi'] ?? '') ? 'selected' : ''; ?>><?= html_escape(($prodi['nama_prodi'] ?? '-') . ' · ' . ($prodi['kode_prodi'] ?? '-')); ?></option><?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="col-xl-2 col-md-4">
                                        <label class="form-label">Status Mahasiswa</label>
                                        <select name="status_mahasiswa" class="form-select">
                                            <option value="">Semua Status</option>
                                            <?php foreach (($options['student_statuses'] ?? array()) as $value): ?><option value="<?= html_escape($value); ?>" <?= (string) ($filters['status_mahasiswa'] ?? '') === (string) $value ? 'selected' : ''; ?>><?= html_escape($value . ' · ' . cdk_status_mhs_label($value)); ?></option><?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="col-xl-2 col-md-4">
                                        <label class="form-label">Status Code</label>
                                        <select name="status_code" class="form-select">
                                            <option value="">Semua Status Code</option>
                                            <?php foreach (($options['status_codes'] ?? array()) as $value): ?><option value="<?= html_escape($value); ?>" <?= (string) ($filters['status_code'] ?? '') === (string) $value ? 'selected' : ''; ?>><?= html_escape($value); ?><?= (int) $value === 200 ? ' · Lunas' : ''; ?></option><?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="col-xl-2 col-md-4">
                                        <label class="form-label">Tahun</label>
                                        <select name="tahun" class="form-select">
                                            <option value="">Semua Tahun</option>
                                            <?php foreach (($options['years'] ?? array()) as $value): ?><option value="<?= html_escape($value); ?>" <?= (string) ($filters['tahun'] ?? '') === (string) $value ? 'selected' : ''; ?>><?= html_escape($value); ?></option><?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="col-xl-2 col-md-4">
                                        <label class="form-label">Pembayaran Ke</label>
                                        <select name="pembayaran_ke" class="form-select">
                                            <option value="">Semua</option>
                                            <?php foreach (($options['payment_numbers'] ?? array()) as $value): ?><option value="<?= html_escape($value); ?>" <?= (string) ($filters['pembayaran_ke'] ?? '') === (string) $value ? 'selected' : ''; ?>>Ke-<?= html_escape($value); ?></option><?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="col-xl-4 col-md-8">
                                        <label class="form-label">Cari NIM / Nama Mahasiswa</label>
                                        <input type="text" name="q" class="form-control" maxlength="100" value="<?= html_escape($filters['q'] ?? ''); ?>" placeholder="Ketik NIM atau nama mahasiswa">
                                    </div>
                                    <div class="col-xl-2 col-md-4">
                                        <label class="form-label">Baris / Halaman</label>
                                        <select name="per_page" class="form-select">
                                            <?php foreach (array(25, 50, 100) as $pp): ?><option value="<?= $pp; ?>" <?= (int) ($filters['per_page'] ?? 50) === $pp ? 'selected' : ''; ?>><?= $pp; ?> data</option><?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="col-xl-4 col-md-8 d-flex gap-2 filter-actions">
                                        <button class="btn btn-primary flex-fill"><i class="bx bx-filter-alt me-1"></i>Terapkan Filter</button>
                                        <a href="<?= base_url('admin/Control_database_keuangan?tab=data'); ?>" class="btn btn-outline-secondary"><i class="bx bx-reset"></i></a>
                                    </div>
                                </div>
                            </form>
                        </div>

                        <div class="card-body pt-0">
                            <div id="bulkBar" class="bulk-bar align-items-center justify-content-between gap-2 flex-wrap mb-3">
                                <div><strong id="bulkCount">0</strong> data dipilih</div>
                                <div class="d-flex flex-wrap gap-2">
                                    <button type="button" class="btn btn-sm btn-outline-primary" id="bulkRepairBtn"><i class="bx bx-wrench me-1"></i>Repair Terpilih</button>
                                    <button type="button" class="btn btn-sm btn-danger" id="bulkDeleteBtn"><i class="bx bx-trash me-1"></i>Hapus Terpilih</button>
                                    <button type="button" class="btn btn-sm btn-outline-secondary" id="bulkCancelBtn">Batal Pilih</button>
                                </div>
                            </div>

                            <?= form_open('admin/Control_database_keuangan/bulk_delete', array('id' => 'bulkForm')); ?>
                                <input type="hidden" name="return_query" value="<?= html_escape($returnQuery); ?>">
                                <div class="table-wrap border rounded">
                                    <table class="table table-hover align-middle data-table">
                                        <thead>
                                            <tr>
                                                <th class="text-center" style="width:44px"><input class="form-check-input" type="checkbox" id="checkAll" aria-label="Pilih semua data di halaman"></th>
                                                <th style="width:56px">No</th>
                                                <th>Mahasiswa</th>
                                                <th>Program Studi</th>
                                                <th>Jenis Tagihan</th>
                                                <th>Periode</th>
                                                <th class="text-center">Pembayaran</th>
                                                <th style="min-width:205px">Nilai Tagihan</th>
                                                <th>Status Code</th>
                                                <th class="text-center">Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if (!$rows): ?>
                                                <tr><td colspan="10" class="text-center text-muted py-5"><i class="bx bx-search-alt fs-2 d-block mb-2"></i>Tidak ada data tagihan untuk filter ini.</td></tr>
                                            <?php else: ?>
                                                <?php $no = (int) ($pagination['from'] ?? 1); foreach ($rows as $row): ?>
                                                    <?php
                                                    $displayName = trim((string) ($row['nama'] ?? '')) !== '' ? $row['nama'] : ($row['master_nama'] ?? '-');
                                                    $studentStatus = (string) ($row['status_mahasiswa'] ?? '');
                                                    $prodiName = trim((string) ($row['nama_prodi'] ?? '')) !== '' ? $row['nama_prodi'] : 'Nama prodi tidak ditemukan';
                                                    $statusCode = (int) ($row['status_code'] ?? 0);
                                                    ?>
                                                    <tr>
                                                        <td class="text-center"><input class="form-check-input row-check" type="checkbox" name="ids[]" value="<?= (int) $row['id']; ?>" aria-label="Pilih tagihan #<?= (int) $row['id']; ?>"></td>
                                                        <td class="text-muted small"><?= $no++; ?></td>
                                                        <td style="min-width:190px">
                                                            <div class="student-name"><?= html_escape($displayName); ?></div>
                                                            <div class="subtext mt-1">NIM <?= html_escape($row['nim'] ?? '-'); ?> · ID #<?= (int) $row['id']; ?></div>
                                                            <span class="badge bg-label-<?= cdk_status_mhs_class($studentStatus); ?> mt-1"><?= html_escape(cdk_status_mhs_label($studentStatus)); ?><?= $studentStatus !== '' ? ' · ' . html_escape($studentStatus) : ''; ?></span>
                                                        </td>
                                                        <td style="min-width:180px"><div class="prodi-name"><?= html_escape($prodiName); ?></div><div class="subtext mt-1"><?= html_escape($row['kode_prodi'] ?? '-'); ?></div></td>
                                                        <td><div class="fw-semibold"><?= html_escape($row['jenistagihan'] ?? '-'); ?></div><?php if ((int) ($row['tagihan_khusus'] ?? 0) === 1): ?><span class="badge bg-label-info mt-1">Khusus</span><?php endif; ?></td>
                                                        <td><div class="fw-semibold"><?= html_escape($row['period'] ?? '-'); ?></div><div class="subtext">Tahun <?= html_escape($row['tahun'] ?? '-'); ?></div></td>
                                                        <td class="text-center"><span class="badge bg-label-secondary">Ke-<?= (int) ($row['pembayaran_ke'] ?? 0); ?></span><?php if ((int) ($row['status_perjanjian'] ?? 0) === 1): ?><div class="subtext mt-1">Perjanjian aktif</div><?php endif; ?></td>
                                                        <td>
                                                            <div class="money-line"><span>Total</span><strong><?= html_escape(cdk_money($row['tottagihan'] ?? 0)); ?></strong></div>
                                                            <div class="money-line"><span>Jumlah</span><strong><?= html_escape(cdk_money($row['jumlahtagihan'] ?? 0)); ?></strong></div>
                                                            <div class="money-line"><span>Sisa</span><strong><?= html_escape(cdk_money($row['sisa'] ?? 0)); ?></strong></div>
                                                        </td>
                                                        <td style="min-width:125px"><span class="badge bg-label-<?= cdk_status_code_class($statusCode); ?>"><?= $statusCode; ?></span><div class="subtext mt-1 text-capitalize"><?= html_escape(cdk_status_code_label($statusCode, $row['transaction_status'] ?? '')); ?></div></td>
                                                        <td class="text-center">
                                                            <div class="dropdown">
                                                                <button class="btn btn-sm btn-icon btn-outline-primary dropdown-toggle hide-arrow" type="button" data-bs-toggle="dropdown"><i class="bx bx-dots-vertical-rounded"></i></button>
                                                                <ul class="dropdown-menu dropdown-menu-end">
                                                                    <li><button type="button" class="dropdown-item btn-detail" data-id="<?= (int) $row['id']; ?>"><i class="bx bx-show me-2"></i>Lihat Detail</button></li>
                                                                    <li><button type="button" class="dropdown-item btn-edit" data-id="<?= (int) $row['id']; ?>"><i class="bx bx-edit me-2"></i>Edit Tagihan</button></li>
                                                                    <li><button type="button" class="dropdown-item btn-status" data-id="<?= (int) $row['id']; ?>" data-code="<?= $statusCode; ?>" data-name="<?= html_escape($displayName); ?>"><i class="bx bx-refresh me-2"></i>Ubah Status</button></li>
                                                                    <li><button type="button" class="dropdown-item btn-repair" data-id="<?= (int) $row['id']; ?>"><i class="bx bx-wrench me-2"></i>Repair Aman</button></li>
                                                                    <li><hr class="dropdown-divider"></li>
                                                                    <li><button type="button" class="dropdown-item text-danger btn-delete" data-id="<?= (int) $row['id']; ?>" data-name="<?= html_escape($displayName); ?>"><i class="bx bx-trash me-2"></i>Hapus</button></li>
                                                                </ul>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?= form_close(); ?>

                            <div class="d-flex flex-column flex-lg-row justify-content-between align-items-lg-center gap-2 mt-3">
                                <div class="small text-muted">Menampilkan <?= (int) ($pagination['from'] ?? 0); ?>–<?= (int) ($pagination['to'] ?? 0); ?> dari <?= number_format((int) ($pagination['total_rows'] ?? 0), 0, ',', '.'); ?> data.</div>
                                <?php if ((int) ($pagination['total_pages'] ?? 1) > 1): ?>
                                    <?php $page = (int) $pagination['page']; $totalPages = (int) $pagination['total_pages']; $start = max(1, $page - 2); $end = min($totalPages, $page + 2); ?>
                                    <nav aria-label="Pagination Control Database Keuangan"><ul class="pagination pagination-sm mb-0">
                                        <?php $pq = $queryBase; $pq['page'] = max(1, $page - 1); ?><li class="page-item <?= $page <= 1 ? 'disabled' : ''; ?>"><a class="page-link" href="<?= $page <= 1 ? '#' : base_url('admin/Control_database_keuangan?' . http_build_query($pq)); ?>"><i class="bx bx-chevron-left"></i></a></li>
                                        <?php if ($start > 1): $pq = $queryBase; $pq['page'] = 1; ?><li class="page-item"><a class="page-link" href="<?= base_url('admin/Control_database_keuangan?' . http_build_query($pq)); ?>">1</a></li><?php if ($start > 2): ?><li class="page-item disabled"><span class="page-link">…</span></li><?php endif; endif; ?>
                                        <?php for ($p = $start; $p <= $end; $p++): $pq = $queryBase; $pq['page'] = $p; ?><li class="page-item <?= $p === $page ? 'active' : ''; ?>"><a class="page-link" href="<?= base_url('admin/Control_database_keuangan?' . http_build_query($pq)); ?>"><?= $p; ?></a></li><?php endfor; ?>
                                        <?php if ($end < $totalPages): if ($end < $totalPages - 1): ?><li class="page-item disabled"><span class="page-link">…</span></li><?php endif; $pq = $queryBase; $pq['page'] = $totalPages; ?><li class="page-item"><a class="page-link" href="<?= base_url('admin/Control_database_keuangan?' . http_build_query($pq)); ?>"><?= $totalPages; ?></a></li><?php endif; ?>
                                        <?php $pq = $queryBase; $pq['page'] = min($totalPages, $page + 1); ?><li class="page-item <?= $page >= $totalPages ? 'disabled' : ''; ?>"><a class="page-link" href="<?= $page >= $totalPages ? '#' : base_url('admin/Control_database_keuangan?' . http_build_query($pq)); ?>"><i class="bx bx-chevron-right"></i></a></li>
                                    </ul></nav>
                                <?php endif; ?>
                            </div>
                        </div>

                    <?php elseif ($activeTab === 'repair'): ?>
                        <div class="card-body cdk-tab-body">
                            <div class="cdk-tab-gap" aria-hidden="true"></div>
                            <div class="d-flex flex-column flex-lg-row justify-content-between align-items-lg-center gap-2 mb-3">
                                <div><h6 class="mb-1">Repair Aman Otomatis</h6><small class="text-muted">Scanner hanya menampilkan anomali yang dapat diperbaiki tanpa menebak status pembayaran: angka negatif dinormalisasi ke 0, serta nama/kode prodi kosong diisi dari master mahasiswa.</small></div>
                                <span class="badge bg-label-warning px-3 py-2">Maks. 200 kandidat / scan</span>
                            </div>
                            <?= form_open('admin/Control_database_keuangan/bulk_repair', array('id' => 'repairBulkForm')); ?>
                                <input type="hidden" name="return_query" value="<?= html_escape(http_build_query(array('tab' => 'repair'))); ?>">
                                <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                                    <div class="small text-muted"><strong><?= count($repairCandidates); ?></strong> kandidat repair aman terdeteksi.</div>
                                    <button type="button" class="btn btn-sm btn-primary" id="repairTabSelectedBtn" disabled><i class="bx bx-wrench me-1"></i>Repair Terpilih</button>
                                </div>
                                <div class="table-responsive border rounded">
                                    <table class="table table-hover align-middle mb-0">
                                        <thead><tr><th style="width:44px"><input class="form-check-input" type="checkbox" id="repairCheckAll"></th><th>ID</th><th>Mahasiswa</th><th>Jenis / Periode</th><th>Temuan Aman</th><th class="text-center">Aksi</th></tr></thead>
                                        <tbody>
                                            <?php if (!$repairCandidates): ?><tr><td colspan="6" class="text-center text-muted py-5"><i class="bx bx-check-shield fs-2 d-block mb-2"></i>Tidak ada kandidat repair aman.</td></tr><?php else: foreach ($repairCandidates as $candidate): ?>
                                                <tr>
                                                    <td><input class="form-check-input repair-check" type="checkbox" name="ids[]" value="<?= (int) $candidate['id']; ?>"></td>
                                                    <td class="small">#<?= (int) $candidate['id']; ?></td>
                                                    <td><div class="fw-semibold"><?= html_escape(trim((string) ($candidate['nama'] ?? '')) !== '' ? $candidate['nama'] : ($candidate['master_nama'] ?? '-')); ?></div><small class="text-muted"><?= html_escape($candidate['nim'] ?? '-'); ?></small></td>
                                                    <td><div class="fw-semibold"><?= html_escape($candidate['jenistagihan'] ?? '-'); ?></div><small class="text-muted"><?= html_escape($candidate['period'] ?? '-'); ?></small></td>
                                                    <td><?php foreach ((array) ($candidate['repair_issues'] ?? array()) as $issue): ?><span class="badge bg-label-warning me-1 mb-1"><?= html_escape($issue); ?></span><?php endforeach; ?></td>
                                                    <td class="text-center"><button type="button" class="btn btn-sm btn-outline-primary btn-repair" data-id="<?= (int) $candidate['id']; ?>"><i class="bx bx-wrench me-1"></i>Repair</button></td>
                                                </tr>
                                            <?php endforeach; endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?= form_close(); ?>
                        </div>

                    <?php elseif ($activeTab === 'sql'): ?>
                        <div class="card-body cdk-tab-body">
                            <div class="cdk-tab-gap" aria-hidden="true"></div>
                            <div class="alert alert-warning py-2"><i class="bx bx-error-circle me-1"></i><strong>Expert Mode.</strong> SQL Console menjalankan satu statement per eksekusi. SELECT tanpa LIMIT otomatis dibatasi 500 baris. Perubahan SQL dicatat ke Audit Log.</div>
                            <?= form_open('admin/Control_database_keuangan/sql_execute', array('id' => 'sqlForm')); ?>
                                <label class="form-label fw-semibold">SQL Query</label>
                                <textarea class="form-control sql-editor" name="sql_query" id="sqlQuery" spellcheck="false" placeholder="SELECT * FROM tagihan WHERE period='20261' AND status_code<>200"><?= html_escape((string) (($sql_result['sql'] ?? '') !== '' ? ($sql_result['sql'] ?? '') : '')); ?></textarea>
                                <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mt-3">
                                    <small class="text-muted">Diizinkan: SELECT, SHOW, DESCRIBE, EXPLAIN, UPDATE, INSERT, DELETE, REPLACE, CREATE, ALTER, DROP, TRUNCATE, RENAME, SET.</small>
                                    <button class="btn btn-primary" type="submit"><i class="bx bx-play me-1"></i>Execute</button>
                                </div>
                            <?= form_close(); ?>

                            <?php if (is_array($sql_result ?? null)): ?>
                                <hr class="my-4">
                                <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                                    <div><h6 class="mb-1">Hasil SQL Console</h6><small class="text-muted"><?= html_escape(strtoupper((string) ($sql_result['keyword'] ?? '-'))); ?> · <?= number_format((float) ($sql_result['elapsed'] ?? 0), 4); ?> detik</small></div>
                                    <span class="badge bg-label-<?= !empty($sql_result['ok']) ? 'success' : 'danger'; ?>"><?= !empty($sql_result['ok']) ? 'BERHASIL' : 'GAGAL'; ?></span>
                                </div>
                                <?php if (empty($sql_result['ok'])): ?>
                                    <div class="alert alert-danger mb-0"><?= html_escape($sql_result['message'] ?? 'Query gagal.'); ?></div>
                                <?php elseif (($sql_result['mode'] ?? '') === 'write'): ?>
                                    <div class="alert alert-success mb-0">Statement berhasil. Affected rows: <strong><?= (int) ($sql_result['affected_rows'] ?? 0); ?></strong>.</div>
                                <?php else: ?>
                                    <div class="small text-muted mb-2">Baris hasil: <?= number_format((int) ($sql_result['row_count'] ?? 0), 0, ',', '.'); ?><?= (int) ($sql_result['row_count'] ?? 0) >= 500 ? ' · tampilan dibatasi 500 baris' : ''; ?></div>
                                    <div class="sql-result border rounded">
                                        <table class="table table-sm table-hover mb-0">
                                            <?php $sqlColumns = (array) ($sql_result['columns'] ?? array()); ?>
                                            <thead><tr><?php foreach ($sqlColumns as $col): ?><th class="text-nowrap"><?= html_escape($col); ?></th><?php endforeach; ?></tr></thead>
                                            <tbody>
                                                <?php if (empty($sql_result['rows'])): ?><tr><td colspan="<?= max(1, count($sqlColumns)); ?>" class="text-center text-muted py-4">Query tidak mengembalikan baris.</td></tr><?php else: foreach ((array) $sql_result['rows'] as $sqlRow): ?><tr><?php foreach ($sqlColumns as $col): ?><td class="small text-nowrap"><?= html_escape((string) ($sqlRow[$col] ?? '')); ?></td><?php endforeach; ?></tr><?php endforeach; endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>

                    <?php else: ?>
                        <div class="card-body cdk-tab-body">
                            <div class="cdk-tab-gap" aria-hidden="true"></div>
                            <?php if (empty($audit_ready)): ?>
                                <div class="alert alert-warning mb-0">Tabel <code>app_audit_trail</code> belum tersedia. Data tagihan tetap dapat digunakan, tetapi histori snapshot tidak dapat ditampilkan.</div>
                            <?php else: ?>
                                <div class="d-flex justify-content-between align-items-center mb-3"><div><h6 class="mb-1">Riwayat Control Database Keuangan</h6><small class="text-muted">150 aktivitas terbaru dari modul <?= html_escape('keuangan.database_control'); ?>.</small></div><span class="badge bg-label-secondary"><?= count($auditRows); ?> log</span></div>
                                <div class="table-responsive border rounded">
                                    <table class="table table-hover align-middle mb-0">
                                        <thead><tr><th>Waktu</th><th>Aksi</th><th>Entity</th><th>User</th><th>Snapshot / Catatan</th></tr></thead>
                                        <tbody>
                                            <?php if (!$auditRows): ?><tr><td colspan="5" class="text-center text-muted py-5">Belum ada aktivitas pada modul ini.</td></tr><?php else: foreach ($auditRows as $log): ?>
                                                <tr>
                                                    <td class="small text-nowrap"><?= html_escape($log['created_at'] ?? '-'); ?></td>
                                                    <td><span class="badge bg-label-primary"><?= html_escape(strtoupper((string) ($log['action'] ?? '-'))); ?></span></td>
                                                    <td><div class="fw-semibold"><?= html_escape($log['entity_type'] ?? '-'); ?></div><small class="text-muted">#<?= html_escape($log['entity_id'] ?? '-'); ?></small></td>
                                                    <td class="small">ID <?= (int) ($log['user_id'] ?? 0); ?><div class="text-muted"><?= html_escape($log['ip_address'] ?? '-'); ?></div></td>
                                                    <td style="min-width:320px">
                                                        <div class="small mb-1"><?= html_escape($log['notes'] ?? '-'); ?></div>
                                                        <?php if (!empty($log['before_json']) || !empty($log['after_json'])): ?>
                                                            <details><summary class="small text-primary" style="cursor:pointer">Lihat snapshot</summary><div class="row g-2 mt-1"><div class="col-lg-6"><div class="small text-muted mb-1">Before</div><pre class="audit-json mb-0"><?= html_escape($log['before_json'] ?? '-'); ?></pre></div><div class="col-lg-6"><div class="small text-muted mb-1">After</div><pre class="audit-json mb-0"><?= html_escape($log['after_json'] ?? '-'); ?></pre></div></div></details>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<form id="singleDeleteForm" method="post" action="">
    <input type="hidden" name="<?= html_escape($csrfName); ?>" value="<?= html_escape($csrfHash); ?>">
    <input type="hidden" name="return_query" value="<?= html_escape($returnQuery); ?>">
</form>
<form id="singleRepairForm" method="post" action="">
    <input type="hidden" name="<?= html_escape($csrfName); ?>" value="<?= html_escape($csrfHash); ?>">
    <input type="hidden" name="return_query" value="<?= html_escape($returnQuery); ?>">
</form>

<div class="modal fade" id="detailModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header"><div><h5 class="modal-title mb-0">Detail Record Tagihan</h5><small class="text-muted" id="detailSubtitle">-</small></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body"><div id="detailGrid" class="detail-grid"><div class="text-muted">Memuat data...</div></div></div>
            <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Tutup</button></div>
        </div>
    </div>
</div>

<div class="modal fade" id="editModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <form class="modal-content" id="editForm" method="post" action="">
            <input type="hidden" name="<?= html_escape($csrfName); ?>" value="<?= html_escape($csrfHash); ?>">
            <input type="hidden" name="return_query" value="<?= html_escape($returnQuery); ?>">
            <div class="modal-header"><div><h5 class="modal-title mb-0">Edit Data Tagihan</h5><small class="text-muted" id="editSubtitle">-</small></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body">
                <div class="alert alert-info py-2"><i class="bx bx-info-circle me-1"></i>Field <code>signature_key</code> sengaja tidak ditampilkan di form. Nilai existing tetap dipertahankan dan dapat ditangani melalui SQL Console bila diperlukan.</div>
                <div class="row g-3">
                    <div class="col-12"><div class="edit-section"><div class="edit-section-title"><i class="bx bx-receipt me-1"></i>Tagihan & Identitas</div><div class="row g-3">
                        <div class="col-md-3"><label class="form-label">NIM</label><input class="form-control" name="nim" maxlength="20"></div>
                        <div class="col-md-5"><label class="form-label">Nama</label><input class="form-control" name="nama" maxlength="50"></div>
                        <div class="col-md-2"><label class="form-label">Kode Prodi</label><input class="form-control" name="kode_prodi" maxlength="20"></div>
                        <div class="col-md-2"><label class="form-label">ID Akun</label><input class="form-control" name="id_akun" maxlength="10"></div>
                        <div class="col-md-4"><label class="form-label">Jenis Tagihan</label><input class="form-control" name="jenistagihan" maxlength="20"></div>
                        <div class="col-md-2"><label class="form-label">Periode</label><input class="form-control" name="period" maxlength="5"></div>
                        <div class="col-md-2"><label class="form-label">Tahun</label><input class="form-control" name="tahun" maxlength="5"></div>
                        <div class="col-md-2"><label class="form-label">Pembayaran Ke</label><input type="number" class="form-control" name="pembayaran_ke"></div>
                        <div class="col-md-2"><label class="form-label">Gelombang</label><input class="form-control" name="gelombang" maxlength="2"></div>
                        <div class="col-md-4"><label class="form-label">Bill Period</label><input type="datetime-local" class="form-control" name="billperiod"></div>
                        <div class="col-md-4"><label class="form-label">Tanggal Bayar</label><input type="datetime-local" class="form-control" name="tglbayar"></div>
                        <div class="col-md-2"><label class="form-label">Ditagihkan</label><select class="form-select" name="isditagihkan"><option value="">NULL</option><option value="1">1</option><option value="0">0</option></select></div>
                        <div class="col-md-4"><label class="form-label">ID Tagihan</label><input class="form-control" name="idtagihan" maxlength="50"></div>
                        <div class="col-md-4"><label class="form-label">Nomor Kwitansi</label><input class="form-control" name="nomor_kwitansi" maxlength="100"></div>
                        <div class="col-md-4"><label class="form-label">Total Tagihan</label><input type="number" class="form-control" name="tottagihan"></div>
                        <div class="col-md-4"><label class="form-label">Jumlah Tagihan</label><input type="number" class="form-control" name="jumlahtagihan"></div>
                        <div class="col-md-4"><label class="form-label">Sisa</label><input type="number" class="form-control" name="sisa"></div>
                        <div class="col-12"><label class="form-label">Keterangan</label><textarea class="form-control" name="keterangan" rows="2"></textarea></div>
                    </div></div></div>

                    <div class="col-12"><div class="edit-section"><div class="edit-section-title"><i class="bx bx-credit-card me-1"></i>Status & Transaksi</div><div class="row g-3">
                        <div class="col-md-2"><label class="form-label">Status Code</label><input type="number" class="form-control" name="status_code"></div>
                        <div class="col-md-3"><label class="form-label">Transaction Status</label><input class="form-control" name="transaction_status" maxlength="30"></div>
                        <div class="col-md-3"><label class="form-label">Fraud Status</label><input class="form-control" name="fraud_status" maxlength="50"></div>
                        <div class="col-md-4"><label class="form-label">Payment Type</label><input class="form-control" name="payment_type" maxlength="255"></div>
                        <div class="col-md-6"><label class="form-label">Order ID</label><input class="form-control" name="order_id" maxlength="254"></div>
                        <div class="col-md-6"><label class="form-label">Transaction ID</label><input class="form-control" name="transaction_id" maxlength="255"></div>
                        <div class="col-md-4"><label class="form-label">Gross Amount</label><input class="form-control" name="gross_amount" maxlength="255"></div>
                        <div class="col-md-4"><label class="form-label">Transaction Time</label><input class="form-control" name="transaction_time" maxlength="255"></div>
                        <div class="col-md-4"><label class="form-label">Settlement Time</label><input class="form-control" name="settlement_time" maxlength="50"></div>
                        <div class="col-md-4"><label class="form-label">Bank</label><input class="form-control" name="bank" maxlength="255"></div>
                        <div class="col-md-4"><label class="form-label">VA Number</label><input class="form-control" name="va_number" maxlength="255"></div>
                        <div class="col-md-4"><label class="form-label">Reference ID</label><input class="form-control" name="reference_id" maxlength="255"></div>
                        <div class="col-md-4"><label class="form-label">Expired Date</label><input class="form-control" name="expired_date" maxlength="255"></div>
                        <div class="col-md-4"><label class="form-label">Expired Time</label><input class="form-control" name="expired_time" maxlength="255"></div>
                        <div class="col-md-4"><label class="form-label">Currency</label><input class="form-control" name="currency" maxlength="10"></div>
                        <div class="col-md-6"><label class="form-label">PDF URL</label><input class="form-control" name="pdf_url" maxlength="255"></div>
                        <div class="col-md-6"><label class="form-label">Finish Redirect URL</label><input class="form-control" name="finish_redirect_url" maxlength="255"></div>
                        <div class="col-md-6"><label class="form-label">Bukti Bayar</label><input class="form-control" name="bukti_bayar" maxlength="255"></div>
                        <div class="col-md-6"><label class="form-label">Status Message</label><input class="form-control" name="status_message" maxlength="255"></div>
                    </div></div></div>

                    <div class="col-12"><div class="edit-section"><div class="edit-section-title"><i class="bx bx-calendar-check me-1"></i>Perjanjian & Cicilan</div><div class="row g-3">
                        <div class="col-md-3"><label class="form-label">Akhir Perjanjian</label><input class="form-control" name="akhir_perjanjian" maxlength="50"></div>
                        <div class="col-md-2"><label class="form-label">Status Perjanjian</label><input type="number" class="form-control" name="status_perjanjian"></div>
                        <div class="col-md-2"><label class="form-label">Tagihan Khusus</label><input type="number" class="form-control" name="tagihan_khusus"></div>
                        <div class="col-md-2"><label class="form-label">ID Tagihan Induk</label><input type="number" class="form-control" name="id_tagihan_induk"></div>
                        <div class="col-md-3"><label class="form-label">Skema Cicilan</label><input class="form-control" name="skema_cicilan" maxlength="20"></div>
                        <div class="col-md-3"><label class="form-label">Jumlah Cicilan</label><input type="number" class="form-control" name="jumlah_cicilan"></div>
                        <div class="col-md-3"><label class="form-label">Jatuh Tempo Cicilan</label><input type="date" class="form-control" name="jatuh_tempo_cicilan"></div>
                    </div></div></div>
                </div>
            </div>
            <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Batal</button><button type="submit" class="btn btn-primary"><i class="bx bx-save me-1"></i>Simpan Perubahan</button></div>
        </form>
    </div>
</div>

<div class="modal fade" id="statusModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <form class="modal-content" id="statusForm" method="post" action="">
            <input type="hidden" name="<?= html_escape($csrfName); ?>" value="<?= html_escape($csrfHash); ?>">
            <input type="hidden" name="return_query" value="<?= html_escape($returnQuery); ?>">
            <div class="modal-header"><div><h5 class="modal-title mb-0">Ubah Status Code</h5><small class="text-muted" id="statusSubtitle">-</small></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body">
                <label class="form-label">Status Code</label>
                <input type="number" class="form-control" name="status_code" id="statusCodeInput" list="statusCodeList" required>
                <datalist id="statusCodeList"><?php foreach (($options['status_codes'] ?? array()) as $value): ?><option value="<?= html_escape($value); ?>"><?php endforeach; ?><option value="200"></datalist>
                <small class="text-muted d-block mt-2">Nilai disimpan persis sebagai angka status_code. Kode 200 ditampilkan sebagai Lunas; kode lain tetap mengikuti data transaksi existing.</small>
            </div>
            <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Batal</button><button type="submit" class="btn btn-primary">Simpan Status</button></div>
        </form>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    var baseUrl = <?= json_encode(base_url('admin/Control_database_keuangan')); ?>;
    var bulkForm = document.getElementById('bulkForm');
    var checks = Array.prototype.slice.call(document.querySelectorAll('.row-check'));
    var checkAll = document.getElementById('checkAll');
    var bulkBar = document.getElementById('bulkBar');
    var bulkCount = document.getElementById('bulkCount');

    function selectedCount() {
        return checks.filter(function (c) { return c.checked; }).length;
    }

    function updateBulkUi() {
        var count = selectedCount();
        if (bulkCount) bulkCount.textContent = count;
        if (bulkBar) bulkBar.classList.toggle('is-active', count > 0);
        if (checkAll) {
            checkAll.checked = checks.length > 0 && count === checks.length;
            checkAll.indeterminate = count > 0 && count < checks.length;
        }
    }

    if (checkAll) {
        checkAll.addEventListener('change', function () {
            checks.forEach(function (c) { c.checked = checkAll.checked; });
            updateBulkUi();
        });
    }
    checks.forEach(function (c) { c.addEventListener('change', updateBulkUi); });

    var bulkCancel = document.getElementById('bulkCancelBtn');
    if (bulkCancel) bulkCancel.addEventListener('click', function () { checks.forEach(function (c) { c.checked = false; }); updateBulkUi(); });

    function swalConfirm(title, text, confirmText, icon) {
        if (window.Swal && typeof Swal.fire === 'function') {
            return Swal.fire({title:title,text:text,icon:icon || 'warning',showCancelButton:true,confirmButtonText:confirmText,cancelButtonText:'Batal',reverseButtons:true});
        }
        return Promise.resolve({isConfirmed: window.confirm(text)});
    }

    var bulkDelete = document.getElementById('bulkDeleteBtn');
    if (bulkDelete) bulkDelete.addEventListener('click', function () {
        var count = selectedCount();
        if (!count) return;
        swalConfirm('Hapus data terpilih?', count + ' data tagihan akan dihapus.', 'Ya, Hapus', 'warning').then(function (result) {
            if (result.isConfirmed) { bulkForm.action = baseUrl + '/bulk_delete'; bulkForm.submit(); }
        });
    });

    var bulkRepair = document.getElementById('bulkRepairBtn');
    if (bulkRepair) bulkRepair.addEventListener('click', function () {
        var count = selectedCount();
        if (!count) return;
        swalConfirm('Repair data terpilih?', 'Repair hanya menormalkan nilai negatif dan mengisi identitas kosong dari master mahasiswa.', 'Ya, Repair', 'question').then(function (result) {
            if (result.isConfirmed) { bulkForm.action = baseUrl + '/bulk_repair'; bulkForm.submit(); }
        });
    });

    document.querySelectorAll('.btn-delete').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var id = this.dataset.id;
            var name = this.dataset.name || '';
            swalConfirm('Hapus tagihan #' + id + '?', name ? ('Data tagihan milik ' + name + ' akan dihapus.') : 'Data tagihan akan dihapus.', 'Ya, Hapus', 'warning').then(function (result) {
                if (result.isConfirmed) {
                    var form = document.getElementById('singleDeleteForm');
                    form.action = baseUrl + '/delete/' + encodeURIComponent(id);
                    form.submit();
                }
            });
        });
    });

    document.querySelectorAll('.btn-repair').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var id = this.dataset.id;
            swalConfirm('Repair tagihan #' + id + '?', 'Repair aman tidak mengubah status pembayaran secara otomatis.', 'Ya, Repair', 'question').then(function (result) {
                if (result.isConfirmed) {
                    var form = document.getElementById('singleRepairForm');
                    form.action = baseUrl + '/repair/' + encodeURIComponent(id);
                    form.submit();
                }
            });
        });
    });

    var statusModal = document.getElementById('statusModal');
    var statusInstance = statusModal ? new bootstrap.Modal(statusModal) : null;
    document.querySelectorAll('.btn-status').forEach(function (btn) {
        btn.addEventListener('click', function () {
            document.getElementById('statusForm').action = baseUrl + '/change_status/' + encodeURIComponent(this.dataset.id);
            document.getElementById('statusCodeInput').value = this.dataset.code || '';
            document.getElementById('statusSubtitle').textContent = '#' + this.dataset.id + ' · ' + (this.dataset.name || '-');
            statusInstance.show();
        });
    });

    function fetchRow(id) {
        return fetch(baseUrl + '/detail/' + encodeURIComponent(id), {headers:{'X-Requested-With':'XMLHttpRequest'}}).then(function (response) {
            return response.json().then(function (json) {
                if (!response.ok || !json.ok) throw new Error(json.message || 'Gagal mengambil detail.');
                return json.row;
            });
        });
    }

    var detailModal = document.getElementById('detailModal');
    var detailInstance = detailModal ? new bootstrap.Modal(detailModal) : null;
    document.querySelectorAll('.btn-detail').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var id = this.dataset.id;
            document.getElementById('detailGrid').innerHTML = '<div class="text-muted">Memuat data...</div>';
            document.getElementById('detailSubtitle').textContent = 'Tagihan #' + id;
            detailInstance.show();
            fetchRow(id).then(function (row) {
                var grid = document.getElementById('detailGrid');
                grid.innerHTML = '';
                Object.keys(row).forEach(function (key) {
                    var item = document.createElement('div'); item.className = 'detail-item';
                    var k = document.createElement('div'); k.className = 'detail-key'; k.textContent = key;
                    var v = document.createElement('div'); v.className = 'detail-value';
                    var value = row[key]; v.textContent = value === null || value === '' ? '-' : String(value);
                    item.appendChild(k); item.appendChild(v); grid.appendChild(item);
                });
            }).catch(function (err) {
                document.getElementById('detailGrid').innerHTML = '<div class="alert alert-danger mb-0"></div>';
                document.querySelector('#detailGrid .alert').textContent = err.message;
            });
        });
    });

    var editModal = document.getElementById('editModal');
    var editInstance = editModal ? new bootstrap.Modal(editModal) : null;
    function datetimeLocal(value) {
        if (!value || value === '0000-00-00 00:00:00') return '';
        return String(value).replace(' ', 'T').slice(0, 16);
    }
    document.querySelectorAll('.btn-edit').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var id = this.dataset.id;
            fetchRow(id).then(function (row) {
                var form = document.getElementById('editForm');
                form.action = baseUrl + '/update/' + encodeURIComponent(id);
                form.querySelectorAll('[name]').forEach(function (input) {
                    var name = input.name;
                    if (!(name in row)) return;
                    var value = row[name];
                    if (name === 'billperiod' || name === 'tglbayar') value = datetimeLocal(value);
                    input.value = value === null ? '' : String(value);
                });
                document.getElementById('editSubtitle').textContent = 'ID #' + id + ' · ' + (row.nim || '-') + ' · ' + (row.nama || '-');
                editInstance.show();
            }).catch(function (err) {
                if (window.Swal) Swal.fire({icon:'error',title:'Gagal',text:err.message}); else alert(err.message);
            });
        });
    });

    var sqlForm = document.getElementById('sqlForm');
    if (sqlForm) {
        sqlForm.addEventListener('submit', function (event) {
            var sql = (document.getElementById('sqlQuery').value || '').trim();
            var keyword = (sql.match(/^([a-zA-Z]+)/) || [,''])[1].toUpperCase();
            var read = ['SELECT','SHOW','DESCRIBE','DESC','EXPLAIN'].indexOf(keyword) !== -1;
            if (sql === '' || read) return;
            event.preventDefault();
            swalConfirm('Jalankan SQL perubahan?', keyword + ' dapat mengubah data atau struktur database.', 'Ya, Execute', 'warning').then(function (result) {
                if (result.isConfirmed) sqlForm.submit();
            });
        });
    }

    var repairBulkForm = document.getElementById('repairBulkForm');
    var repairChecks = Array.prototype.slice.call(document.querySelectorAll('.repair-check'));
    var repairCheckAll = document.getElementById('repairCheckAll');
    var repairSelectedBtn = document.getElementById('repairTabSelectedBtn');
    function updateRepairSelection() {
        var count = repairChecks.filter(function (c) { return c.checked; }).length;
        if (repairSelectedBtn) repairSelectedBtn.disabled = count === 0;
        if (repairCheckAll) {
            repairCheckAll.checked = repairChecks.length > 0 && count === repairChecks.length;
            repairCheckAll.indeterminate = count > 0 && count < repairChecks.length;
        }
    }
    if (repairCheckAll) repairCheckAll.addEventListener('change', function () { repairChecks.forEach(function (c) { c.checked = repairCheckAll.checked; }); updateRepairSelection(); });
    repairChecks.forEach(function (c) { c.addEventListener('change', updateRepairSelection); });
    if (repairSelectedBtn) repairSelectedBtn.addEventListener('click', function () {
        var count = repairChecks.filter(function (c) { return c.checked; }).length;
        if (!count) return;
        swalConfirm('Repair data terpilih?', count + ' data akan diproses dengan rule repair aman.', 'Ya, Repair', 'question').then(function (result) {
            if (result.isConfirmed) repairBulkForm.submit();
        });
    });

    updateBulkUi();
    updateRepairSelection();
});
</script>
