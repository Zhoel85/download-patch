<?php
error_reporting(E_ALL); ini_set('display_errors','1');
$root=__DIR__;
if(!is_dir($root.'/application')) die('ERROR: jalankan dari root portal CI3.');
function putf($p,$c){$d=dirname($p);if(!is_dir($d)&&!mkdir($d,0755,true))die('Gagal mkdir '.$d);if(file_put_contents($p,$c)===false)die('Gagal tulis '.$p);}
$controller=<<<'PHP'
<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Security_center extends CI_Controller {
    private $dataDir;
    private $apps = array(
      '1ujiportal'=>'Uji Portal','1ujiresmipmb'=>'PMB / GoKampus','aplikasiekknlp3m'=>'Aplikasi KKN LP3M',
      'aplikasipresensi'=>'Aplikasi Presensi','magangfkip'=>'Magang FKIP','MagangUntukKesehatanSaja'=>'Magang Kesehatan',
      'PLPKUFKIP'=>'PLP KU FKIP','ppgumsrappang'=>'PPG UMS Rappang','siakad_new_migrasi'=>'Portal Akademik / SIAKAD','zujiancbt'=>'Ujian CBT'
    );
    private $ioc = array(
      '325ac1929d3bb3a2882ca725e0029c38849b306cc127de2214e7d8a61b69d74b','2fd7e6d8f987b243ab1839249551f62adce19704c47d3d0c8dd9e57ea5b9c6b3',
      '5b6af2e2ce89956928535043a5aa6de00bec546b949b66f0fee28120955fc208','43a66916abea3180563cf0c39fa131ac7af398569a561c2c89e20c64e581f2c9',
      'd23d8912d2c2f5005cff6071141353a155ec6043a43ddcf8a9a47e8c6ebada01','f77b492aeeadc5b29e706f67239f3577b655ec67c2280fd9de8481cc17bd70e3',
      '05432134c5007059c9a9f672b8463d78705f075ca587263209ee39a79c72bfb0','47d4ff3a5e54aee590dd968ff29d94040d910e4ed7fa2216e2e75b80a66c4f73',
      '9f12dec240ace528d013ce10aacfcb3bc6dc1df1ff3f15d7de7df42202c3cd1c','d1179dd67fcff456b56cd0cfbe484cbf692043123b59987d2f9e8cb069a38190',
      'a9b64429701b3670453db3e2a7dcef4e858bf9fae69030708f8826724d690f1a','653059a31f870937373fbbc7c5e5946ec7d1ebf5061857f5269e444823ded0ad',
      '763e84c61986af314415ed00a39f463ae7c0bc8ac4922dd50c75cfab649f4815','7295a39e4a3cefcb378b0d745f2d17861e98df7941d4d6584e54a09f537d3f5a',
      '3a58e99f60d528037a24e549dc54f5e2a03483c7b5da50df2a2a6b2ecea0fa66'
    );
    public function __construct(){
      parent::__construct(); $this->load->library('session');
      if((int)$this->session->userdata('id_user')!==1) show_error('Akses hanya untuk Admin Super.',403);
      $this->dataDir=dirname(dirname(rtrim(FCPATH,'/\\'))).'/security_center_data';
      if(!is_dir($this->dataDir)) @mkdir($this->dataDir,0700,true); @chmod($this->dataDir,0700);
    }
    private function root(){return dirname(rtrim(FCPATH,'/\\'));}
    private function appPath($k){return isset($this->apps[$k])?$this->root().DIRECTORY_SEPARATOR.$k:false;}
    private function json($x){$this->output->set_content_type('application/json')->set_output(json_encode($x));}
    public function index(){$this->load->view('admin/security_center/index',array('apps'=>$this->apps));}
    public function start(){
      $app=(string)$this->input->get('app',true);$base=$this->appPath($app);
      if(!$base||!is_dir($base))return $this->json(array('ok'=>false,'msg'=>'Folder aplikasi tidak ditemukan.'));
      $token=date('Ymd_His').'_'.substr(sha1($app.microtime(true)),0,10);
      $s=array('token'=>$token,'app'=>$app,'base'=>$base,'queue'=>array(''),'current'=>null,'entries'=>array(),'idx'=>0,'files'=>0,'dirs'=>0,'critical'=>0,'high'=>0,'review'=>0,'errors'=>0,'done'=>false);
      file_put_contents($this->dataDir.'/state_'.$token.'.json',json_encode($s));
      file_put_contents($this->dataDir.'/UMSR_SECURITY_'.$app.'_'.$token.'.txt',"UMSRAPPANG SECURITY CENTER\nAPP: $app\nSTART: ".date('c')."\n============================================================\n");
      $this->json(array('ok'=>true,'token'=>$token));
    }
    public function batch(){
      $token=preg_replace('/[^A-Za-z0-9_\-]/','',(string)$this->input->get('token',true));$sf=$this->dataDir.'/state_'.$token.'.json';
      if(!is_file($sf))return $this->json(array('ok'=>false,'msg'=>'State scan tidak ditemukan.'));
      $s=json_decode(file_get_contents($sf),true);if(!$s||!empty($s['done']))return $this->json(array('ok'=>true,'done'=>true,'state'=>$s));
      $t0=microtime(true);$processed=0;$report=$this->dataDir.'/UMSR_SECURITY_'.$s['app'].'_'.$token.'.txt';
      while($processed<100&&(microtime(true)-$t0)<1.20){
        if($s['current']===null){
          if(empty($s['queue'])){$s['done']=true;break;}
          $s['current']=array_shift($s['queue']);$dir=$s['base'].($s['current']===''?'':DIRECTORY_SEPARATOR.$s['current']);
          $x=@scandir($dir);if($x===false){$s['errors']++;$s['current']=null;continue;}
          $s['entries']=array_values(array_diff($x,array('.','..')));$s['idx']=0;$s['dirs']++;
        }
        if($s['idx']>=count($s['entries'])){$s['current']=null;$s['entries']=array();$s['idx']=0;continue;}
        $name=$s['entries'][$s['idx']++];$rel=ltrim(($s['current']!==''?$s['current'].'/':'').$name,'/');
        $full=$s['base'].DIRECTORY_SEPARATOR.str_replace('/',DIRECTORY_SEPARATOR,$rel);
        if(is_link($full))continue;if(is_dir($full)){$s['queue'][]=$rel;continue;}if(!is_file($full))continue;
        $processed++;$s['files']++;$this->inspect($full,$rel,$s,$report);
      }
      if($s['done'])file_put_contents($report,"============================================================\nFINISH: ".date('c')."\nFILES: ".$s['files']." | KRITIS: ".$s['critical']." | TINGGI: ".$s['high']." | REVIEW: ".$s['review']." | ERROR: ".$s['errors']."\n",FILE_APPEND);
      file_put_contents($sf,json_encode($s));
      $this->json(array('ok'=>true,'done'=>$s['done'],'state'=>array('files'=>$s['files'],'dirs'=>$s['dirs'],'critical'=>$s['critical'],'high'=>$s['high'],'review'=>$s['review'],'errors'=>$s['errors'])));
    }
    private function finding(&$s,$report,$sev,$type,$rel,$detail){
      if($sev==='KRITIS')$s['critical']++;elseif($sev==='TINGGI')$s['high']++;else$s['review']++;
      file_put_contents($report,'['.$sev.']['.$type.'] '.$rel."\nDETAIL: ".$detail."\n------------------------------------------------------------\n",FILE_APPEND);
    }
    private function inspect($full,$rel,&$s,$report){
      $name=basename($full);$size=@filesize($full);if($size===false)$size=0;$low=strtolower('/'.str_replace('\\','/',$rel));
      $php=(bool)preg_match('/\.(php|php3|php4|php5|php7|php8|phtml|phar)$/i',$name);
      $sus=(bool)preg_match('#/(upload|uploads|assets|img|images|icons|media|storage|temp|tmp|cache)/#i',$low);
      $perm=substr(sprintf('%o',@fileperms($full)),-4);
      if($perm==='0777'||$perm==='0666')$this->finding($s,$report,'TINGGI','WORLD_WRITABLE',$rel,'Permission '.$perm);
      if(preg_match('/\.(exe|so|bin|cgi)$/i',$name))$this->finding($s,$report,'TINGGI','EXECUTABLE',$rel,'Executable/binary');
      if(preg_match('/\.(jpg|jpeg|png|gif|pdf|txt|zip)\.(php|phtml|phar)$/i',$name))$this->finding($s,$report,'KRITIS','DOUBLE_EXTENSION',$rel,'Double extension berbahaya');
      if($php&&$sus)$this->finding($s,$report,'TINGGI','PHP_IN_UPLOAD_ASSET',$rel,'PHP berada di area upload/assets/cache/temp');
      if($php&&preg_match('/^[a-z0-9]{8,}\.(php|phtml)$/i',$name)&&preg_match('/[0-9]/',$name))$this->finding($s,$report,'REVIEW','RANDOM_PHP_NAME',$rel,'Nama PHP terlihat acak');
      if($size>0&&$size<=10485760&&($php||$sus||in_array($size,array(104,105,109,3832,22714,476603,2628736,7748296),true))){
        $h=@hash_file('sha256',$full);if($h&&in_array(strtolower($h),$this->ioc,true))$this->finding($s,$report,'KRITIS','EXACT_IOC',$rel,'SHA256='.$h);
      }
      if($size>0&&$size<=1572864&&($php||$sus)){
        $d=@file_get_contents($full);if($d!==false&&strpos($d,"\0")===false){
          $l=strtolower($d);$score=0;$hits=array();$rules=array('eval('=>6,'shell_exec('=>6,'passthru('=>6,'proc_open('=>6,'popen('=>5,'system('=>5,'exec('=>5,'assert('=>4,'gzinflate('=>5,'gzuncompress('=>5,'base64_decode('=>3,'str_rot13('=>3);
          foreach($rules as $n=>$p)if(strpos($l,$n)!==false){$score+=$p;$hits[]=rtrim($n,'(');}
          if(!$php&&(strpos($l,'<?php')!==false||strpos($l,'<?=')!==false))$this->finding($s,$report,'TINGGI','NONPHP_WITH_PHP_CODE',$rel,'File non-PHP berisi tag PHP');
          if($php&&$score>=10)$this->finding($s,$report,'TINGGI','SUSPICIOUS_PHP',$rel,'Score='.$score.'; '.implode(',',$hits));
          elseif($php&&$score>=6)$this->finding($s,$report,'REVIEW','SUSPICIOUS_PHP',$rel,'Score='.$score.'; '.implode(',',$hits));
        }
      }
    }
    public function download(){
      $token=preg_replace('/[^A-Za-z0-9_\-]/','',(string)$this->input->get('token',true));
      foreach(glob($this->dataDir.'/UMSR_SECURITY_*_'.$token.'.txt') as $f){header('Content-Type:text/plain;charset=UTF-8');header('Content-Disposition:attachment;filename="'.basename($f).'"');readfile($f);return;}show_404();
    }
}
PHP;
$view=<<<'PHP'
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Security Center UMS Rappang</title>
<style>body{font-family:Arial;background:#f5f7fb;margin:0;padding:24px;color:#253046}.wrap{max-width:1100px;margin:auto}.card{background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:20px;margin-bottom:16px}.grid{display:grid;grid-template-columns:repeat(5,1fr);gap:10px}.stat{background:#f8fafc;padding:14px;border-radius:10px;text-align:center}.stat b{display:block;font-size:22px}.bar{height:12px;background:#e5e7eb;border-radius:10px;overflow:hidden}.bar i{display:block;height:100%;width:0;background:#2563eb}.danger{color:#b91c1c}.warn{color:#b45309}select,button,a.btn{padding:10px 12px;font-size:14px}a.btn{display:inline-block;text-decoration:none;border:1px solid #d1d5db;border-radius:7px;color:#111;margin-top:10px}.small{font-size:13px;color:#667085}@media(max-width:800px){.grid{grid-template-columns:1fr 1fr}}</style></head><body><div class="wrap">
<div class="card"><h2 style="margin-top:0">Security Center UMS Rappang</h2><p class="small">Deep scanner read-only, batch maksimum 100 file / ±1,2 detik per request untuk mencegah 504. Akses khusus Admin Super ID 1.</p>
<select id="app"><?php foreach($apps as $k=>$n):?><option value="<?=htmlspecialchars($k,ENT_QUOTES,'UTF-8')?>"><?=htmlspecialchars($n,ENT_QUOTES,'UTF-8')?></option><?php endforeach;?></select> <button id="start">Mulai Deep Scan</button></div>
<div class="card" id="panel" style="display:none"><div class="bar"><i id="bar"></i></div><p id="msg">Menyiapkan...</p><div class="grid">
<div class="stat"><b id="files">0</b>File</div><div class="stat"><b id="dirs">0</b>Folder</div><div class="stat danger"><b id="critical">0</b>Kritis</div><div class="stat warn"><b id="high">0</b>Tinggi</div><div class="stat"><b id="review">0</b>Review</div></div><p>Error: <b id="errors">0</b></p><a id="download" class="btn" style="display:none">Download TXT Report</a></div>
<div class="card"><b>Kebijakan:</b> scanner hanya membaca. TINGGI/REVIEW tidak dihapus otomatis.</div></div>
<script>(function(){var base='<?=rtrim(site_url('admin/security_center'),'/')?>',token=null,tick=0;function get(u){return fetch(u,{credentials:'same-origin'}).then(function(r){return r.json();});}
document.getElementById('start').onclick=function(){var app=document.getElementById('app').value;document.getElementById('panel').style.display='block';document.getElementById('msg').textContent='Membuat sesi scan...';get(base+'/start?app='+encodeURIComponent(app)).then(function(r){if(!r.ok)throw new Error(r.msg||'Gagal');token=r.token;tick=0;step();}).catch(function(e){document.getElementById('msg').textContent=e.message;});};
function step(){get(base+'/batch?token='+encodeURIComponent(token)).then(function(r){if(!r.ok)throw new Error(r.msg||'Gagal');var s=r.state||{};['files','dirs','critical','high','review','errors'].forEach(function(k){if(s[k]!==undefined)document.getElementById(k).textContent=s[k];});tick++;document.getElementById('bar').style.width=Math.min(95,10+(tick%18)*5)+'%';if(r.done){document.getElementById('bar').style.width='100%';document.getElementById('msg').textContent='Scan selesai.';var a=document.getElementById('download');a.href=base+'/download?token='+encodeURIComponent(token);a.style.display='inline-block';}else{document.getElementById('msg').textContent='Scanning batch '+tick+'...';setTimeout(step,180);}}).catch(function(e){document.getElementById('msg').textContent='Scan berhenti: '+e.message;});}})();</script></body></html>
PHP;
putf($root.'/application/controllers/admin/Security_center.php',$controller);
putf($root.'/application/views/admin/security_center/index.php',$view);
$candidates=array();$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root.'/application/views',FilesystemIterator::SKIP_DOTS));
foreach($it as $f){if(!$f->isFile())continue;$n=strtolower($f->getFilename());if(substr($n,-4)!=='.php')continue;if(strpos($n,'menu')!==false||strpos($n,'sidebar')!==false)$candidates[]=$f->getPathname();}
$menuBlock=<<<'PHP'

<?php if ((int)$this->session->userdata('id_user') === 1): ?>
<li class="menu-item"><a href="<?= site_url('admin/security_center') ?>" class="menu-link"><i class="menu-icon tf-icons bx bx-shield-quarter"></i><div>Security Center</div></a></li>
<?php endif; ?>
PHP;
$patched='';
foreach($candidates as $m){$c=file_get_contents($m);if(strpos($c,'admin/security_center')!==false){$patched=$m;break;}if(strpos($c,'menu-item')!==false&&strpos($c,'menu-link')!==false){copy($m,$m.'.bak_security_center_'.date('Ymd_His'));$pos=strripos($c,'</ul>');$new=$pos!==false?substr($c,0,$pos).$menuBlock."\n".substr($c,$pos):$c."\n".$menuBlock;if(file_put_contents($m,$new)!==false){$patched=$m;break;}}}
echo '<!doctype html><meta charset="utf-8"><style>body{font:14px Arial;padding:30px;background:#f5f7fb}.box{max-width:900px;margin:auto;background:white;padding:24px;border-radius:12px}code{background:#f3f4f6;padding:3px 6px}</style><div class="box"><h2>Security Center UMSR — INSTALL OK</h2><p>Controller dan view berhasil dipasang.</p><p>Menu: <code>'.htmlspecialchars($patched?$patched:'tidak ditemukan otomatis').'</code></p><p><b>Hapus file '.basename(__FILE__).' setelah instalasi.</b></p></div>';
