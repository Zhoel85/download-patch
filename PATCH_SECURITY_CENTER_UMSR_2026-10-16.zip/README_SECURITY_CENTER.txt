PATCH SECURITY CENTER UMS RAPPANG - 2026-10-16

Target: CodeIgniter 3 / PHP 7.4 / siakad_new_migrasi.
Akses: hanya session id_user=1.

Fitur:
- Menu Security Center dengan adaptive menu injector + backup.
- Deep scan read-only per aplikasi.
- Batch maksimum 100 file atau ±1,2 detik per request untuk menghindari 504.
- Exact IOC hash, PHP di upload/assets/cache/temp, double extension, executable, permission 777/666, random PHP filename, PHP code dalam file non-PHP, dan heuristic obfuscation/RCE.
- Download TXT report.
- Report/state di luar public_html pada domains/umsrappang.ac.id/security_center_data.

Instalasi:
1. Extract ZIP di root siakad_new_migrasi.
2. Pastikan install_security_center.php sejajar index.php dan application/.
3. Buka install_security_center.php sekali dari browser.
4. Setelah INSTALL OK, hapus install_security_center.php.
5. Login Admin Super id_user=1 dan buka menu Security Center.
6. Jalankan scan satu aplikasi. Scanner tidak menghapus file.
