<?php
/**
 * SECURITY CENTER UMSR V2 - MENU + TEMPLATE FIX
 * Target: siakad_new_migrasi / CI3 / PHP 7.4
 * - memperbaiki salah sisip menu ke partial PDDIKTI
 * - memasang menu hanya di application/views/templates/menu.php
 * - hanya id_user=1
 * - halaman memakai templates/header + templates/menu + templates/footer
 * - deep scan read-only batch kecil untuk menghindari 504
 */
error_reporting(E_ALL);
ini_set('display_errors','1');
$root=__DIR__;
if(!is_dir($root.'/application')) die('ERROR: file harus berada di root siakad_new_migrasi.');

function ensure_dir($d){ if(!is_dir($d) && !@mkdir($d,0755,true)) die('Gagal membuat folder: '.$d); }
function write_file_safe($p,$c){ ensure_dir(dirname($p)); if(@file_put_contents($p,$c)===false) die('Gagal menulis: '.$p); }
function backup_file($p,$tag){ if(is_file($p)){ $b=$p.'.bak_'.$tag.'_'.date('Ymd_His'); if(!@copy($p,$b)) die('Gagal backup: '.$p); return $b; } return ''; }

$controller=<<<'PHP'
<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Security_center extends CI_Controller {

    private $dataDir;

    private $apps = array(
        '1ujiportal' => 'Uji Portal',
        '1ujiresmipmb' => 'PMB / GoKampus',
        'aplikasiekknlp3m' => 'Aplikasi KKN LP3M',
        'aplikasipresensi' => 'Aplikasi Presensi',
        'magangfkip' => 'Magang FKIP',
        'MagangUntukKesehatanSaja' => 'Magang Kesehatan',
        'PLPKUFKIP' => 'PLP KU FKIP',
        'ppgumsrappang' => 'PPG UMS Rappang',
        'siakad_new_migrasi' => 'Portal Akademik / SIAKAD',
        'zujiancbt' => 'Ujian CBT'
    );

    private $ioc = array(
        '325ac1929d3bb3a2882ca725e0029c38849b306cc127de2214e7d8a61b69d74b',
        '2fd7e6d8f987b243ab1839249551f62adce19704c47d3d0c8dd9e57ea5b9c6b3',
        '5b6af2e2ce89956928535043a5aa6de00bec546b949b66f0fee28120955fc208',
        '43a66916abea3180563cf0c39fa131ac7af398569a561c2c89e20c64e581f2c9',
        'd23d8912d2c2f5005cff6071141353a155ec6043a43ddcf8a9a47e8c6ebada01',
        'f77b492aeeadc5b29e706f67239f3577b655ec67c2280fd9de8481cc17bd70e3',
        '05432134c5007059c9a9f672b8463d78705f075ca587263209ee39a79c72bfb0',
        '47d4ff3a5e54aee590dd968ff29d94040d910e4ed7fa2216e2e75b80a66c4f73',
        '9f12dec240ace528d013ce10aacfcb3bc6dc1df1ff3f15d7de7df42202c3cd1c',
        'd1179dd67fcff456b56cd0cfbe484cbf692043123b59987d2f9e8cb069a38190',
        'a9b64429701b3670453db3e2a7dcef4e858bf9fae69030708f8826724d690f1a',
        '653059a31f870937373fbbc7c5e5946ec7d1ebf5061857f5269e444823ded0ad',
        '763e84c61986af314415ed00a39f463ae7c0bc8ac4922dd50c75cfab649f4815',
        '7295a39e4a3cefcb378b0d745f2d17861e98df7941d4d6584e54a09f537d3f5a',
        '3a58e99f60d528037a24e549dc54f5e2a03483c7b5da50df2a2a6b2ecea0fa66'
    );

    public function __construct()
    {
        parent::__construct();
        $this->load->library('session');

        if ((int)$this->session->userdata('id_user') !== 1) {
            show_error('Akses hanya untuk Admin Super.', 403);
        }

        $this->dataDir = dirname(dirname(rtrim(FCPATH, '/\\'))) . '/security_center_data';

        if (!is_dir($this->dataDir)) {
            @mkdir($this->dataDir, 0700, true);
        }

        @chmod($this->dataDir, 0700);
    }

    private function domainPublicRoot()
    {
        return dirname(rtrim(FCPATH, '/\\'));
    }

    private function appPath($key)
    {
        return isset($this->apps[$key])
            ? $this->domainPublicRoot() . DIRECTORY_SEPARATOR . $key
            : false;
    }

    private function json($data)
    {
        $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode($data));
    }

    public function index()
    {
        $data = array(
            'apps' => $this->apps,
            'page_title' => 'Security Center UMS Rappang'
        );

        $this->load->view('templates/header', $data);
        $this->load->view('templates/menu', $data);
        $this->load->view('admin/security_center/index', $data);
        $this->load->view('templates/footer', $data);
    }

    public function start()
    {
        $app = (string)$this->input->get('app', true);
        $base = $this->appPath($app);

        if (!$base || !is_dir($base)) {
            return $this->json(array(
                'ok' => false,
                'msg' => 'Folder aplikasi tidak ditemukan.'
            ));
        }

        $token = date('Ymd_His') . '_' . substr(sha1($app . microtime(true)), 0, 10);

        $state = array(
            'token' => $token,
            'app' => $app,
            'base' => $base,
            'queue' => array(''),
            'current' => null,
            'entries' => array(),
            'idx' => 0,
            'files' => 0,
            'dirs' => 0,
            'critical' => 0,
            'high' => 0,
            'review' => 0,
            'errors' => 0,
            'done' => false
        );

        @file_put_contents(
            $this->dataDir . '/state_' . $token . '.json',
            json_encode($state),
            LOCK_EX
        );

        $report = $this->dataDir . '/UMSR_SECURITY_' . $app . '_' . $token . '.txt';

        @file_put_contents(
            $report,
            "UMSRAPPANG SECURITY CENTER\n"
            . "APP: " . $app . "\n"
            . "START: " . date('c') . "\n"
            . "============================================================\n",
            LOCK_EX
        );

        $this->json(array(
            'ok' => true,
            'token' => $token
        ));
    }

    public function batch()
    {
        $token = preg_replace(
            '/[^A-Za-z0-9_\-]/',
            '',
            (string)$this->input->get('token', true)
        );

        $stateFile = $this->dataDir . '/state_' . $token . '.json';

        if (!is_file($stateFile)) {
            return $this->json(array(
                'ok' => false,
                'msg' => 'State scan tidak ditemukan.'
            ));
        }

        $state = json_decode(@file_get_contents($stateFile), true);

        if (!$state) {
            return $this->json(array(
                'ok' => false,
                'msg' => 'State scan rusak/tidak valid.'
            ));
        }

        if (!empty($state['done'])) {
            return $this->json(array(
                'ok' => true,
                'done' => true,
                'state' => $state
            ));
        }

        $started = microtime(true);
        $processed = 0;

        // Sengaja kecil: menjaga tiap request singkat di shared hosting.
        $maxFilesPerBatch = 80;
        $maxSecondsPerBatch = 0.85;

        $report = $this->dataDir
            . '/UMSR_SECURITY_'
            . $state['app']
            . '_'
            . $token
            . '.txt';

        while (
            $processed < $maxFilesPerBatch
            &&
            (microtime(true) - $started) < $maxSecondsPerBatch
        ) {

            if ($state['current'] === null) {

                if (empty($state['queue'])) {
                    $state['done'] = true;
                    break;
                }

                $state['current'] = array_shift($state['queue']);

                $dir = $state['base']
                    . ($state['current'] === ''
                        ? ''
                        : DIRECTORY_SEPARATOR . $state['current']);

                $entries = @scandir($dir);

                if ($entries === false) {
                    $state['errors']++;
                    $state['current'] = null;
                    continue;
                }

                $state['entries'] = array_values(
                    array_diff($entries, array('.', '..'))
                );

                $state['idx'] = 0;
                $state['dirs']++;
            }

            if ($state['idx'] >= count($state['entries'])) {
                $state['current'] = null;
                $state['entries'] = array();
                $state['idx'] = 0;
                continue;
            }

            $name = $state['entries'][$state['idx']++];

            $rel = ltrim(
                ($state['current'] !== ''
                    ? $state['current'] . '/'
                    : '')
                . $name,
                '/'
            );

            $full = $state['base']
                . DIRECTORY_SEPARATOR
                . str_replace('/', DIRECTORY_SEPARATOR, $rel);

            if (is_link($full)) {
                continue;
            }

            if (is_dir($full)) {
                $state['queue'][] = $rel;
                continue;
            }

            if (!is_file($full)) {
                continue;
            }

            $processed++;
            $state['files']++;

            $this->inspectFile(
                $full,
                $rel,
                $state,
                $report
            );
        }

        if ($state['done']) {
            @file_put_contents(
                $report,
                "============================================================\n"
                . "FINISH: " . date('c') . "\n"
                . "FILES: " . $state['files']
                . " | KRITIS: " . $state['critical']
                . " | TINGGI: " . $state['high']
                . " | REVIEW: " . $state['review']
                . " | ERROR: " . $state['errors']
                . "\n",
                FILE_APPEND | LOCK_EX
            );
        }

        @file_put_contents(
            $stateFile,
            json_encode($state),
            LOCK_EX
        );

        $this->json(array(
            'ok' => true,
            'done' => !empty($state['done']),
            'state' => array(
                'files' => $state['files'],
                'dirs' => $state['dirs'],
                'critical' => $state['critical'],
                'high' => $state['high'],
                'review' => $state['review'],
                'errors' => $state['errors']
            )
        ));
    }

    private function addFinding(&$state, $report, $severity, $type, $rel, $detail)
    {
        if ($severity === 'KRITIS') {
            $state['critical']++;
        } elseif ($severity === 'TINGGI') {
            $state['high']++;
        } else {
            $state['review']++;
        }

        @file_put_contents(
            $report,
            '[' . $severity . '][' . $type . '] ' . $rel . "\n"
            . 'DETAIL: ' . $detail . "\n"
            . "------------------------------------------------------------\n",
            FILE_APPEND | LOCK_EX
        );
    }

    private function inspectFile($full, $rel, &$state, $report)
    {
        $name = basename($full);

        $size = @filesize($full);
        if ($size === false) {
            $size = 0;
        }

        $normalized = strtolower('/' . str_replace('\\', '/', $rel));

        $isPhp = (bool)preg_match(
            '/\.(php|php3|php4|php5|php7|php8|phtml|phar)$/i',
            $name
        );

        $isRiskArea = (bool)preg_match(
            '#/(upload|uploads|assets|img|images|icons|media|storage|temp|tmp|cache)/#i',
            $normalized
        );

        $perm = substr(sprintf('%o', @fileperms($full)), -4);

        if ($perm === '0777' || $perm === '0666') {
            $this->addFinding(
                $state,
                $report,
                'TINGGI',
                'WORLD_WRITABLE',
                $rel,
                'Permission ' . $perm
            );
        }

        if (preg_match('/\.(exe|so|bin|cgi)$/i', $name)) {
            $this->addFinding(
                $state,
                $report,
                'TINGGI',
                'EXECUTABLE',
                $rel,
                'Executable/binary ditemukan'
            );
        }

        if (preg_match(
            '/\.(jpg|jpeg|png|gif|pdf|txt|zip)\.(php|phtml|phar)$/i',
            $name
        )) {
            $this->addFinding(
                $state,
                $report,
                'KRITIS',
                'DOUBLE_EXTENSION',
                $rel,
                'Double extension berbahaya'
            );
        }

        if ($isPhp && $isRiskArea) {
            $this->addFinding(
                $state,
                $report,
                'TINGGI',
                'PHP_IN_UPLOAD_ASSET',
                $rel,
                'PHP berada di area upload/assets/cache/temp'
            );
        }

        if (
            $isPhp
            &&
            preg_match('/^[a-z0-9]{8,}\.(php|phtml)$/i', $name)
            &&
            preg_match('/[0-9]/', $name)
        ) {
            $this->addFinding(
                $state,
                $report,
                'REVIEW',
                'RANDOM_PHP_NAME',
                $rel,
                'Nama PHP terlihat acak'
            );
        }

        // Hash dibatasi pada file yang layak diperiksa.
        if (
            $size > 0
            &&
            $size <= 10485760
            &&
            (
                $isPhp
                ||
                $isRiskArea
                ||
                in_array(
                    $size,
                    array(104,105,109,3832,22714,476603,2628736,7748296),
                    true
                )
            )
        ) {
            $hash = @hash_file('sha256', $full);

            if ($hash && in_array(strtolower($hash), $this->ioc, true)) {
                $this->addFinding(
                    $state,
                    $report,
                    'KRITIS',
                    'EXACT_IOC',
                    $rel,
                    'SHA256=' . $hash
                );
            }
        }

        // Heuristic hanya untuk file kecil/menengah agar scan tetap ringan.
        if (
            $size > 0
            &&
            $size <= 1048576
            &&
            ($isPhp || $isRiskArea)
        ) {

            $data = @file_get_contents($full);

            if ($data !== false && strpos($data, "\0") === false) {

                $low = strtolower($data);

                $score = 0;
                $hits = array();

                $rules = array(
                    'eval(' => 6,
                    'shell_exec(' => 6,
                    'passthru(' => 6,
                    'proc_open(' => 6,
                    'popen(' => 5,
                    'system(' => 5,
                    'exec(' => 5,
                    'assert(' => 4,
                    'gzinflate(' => 5,
                    'gzuncompress(' => 5,
                    'base64_decode(' => 3,
                    'str_rot13(' => 3
                );

                foreach ($rules as $needle => $points) {

                    if (strpos($low, $needle) !== false) {
                        $score += $points;
                        $hits[] = rtrim($needle, '(');
                    }
                }

                if (
                    !$isPhp
                    &&
                    (
                        strpos($low, '<?php') !== false
                        ||
                        strpos($low, '<?=') !== false
                    )
                ) {
                    $this->addFinding(
                        $state,
                        $report,
                        'TINGGI',
                        'NONPHP_WITH_PHP_CODE',
                        $rel,
                        'File non-PHP berisi tag PHP'
                    );
                }

                if ($isPhp && $score >= 10) {
                    $this->addFinding(
                        $state,
                        $report,
                        'TINGGI',
                        'SUSPICIOUS_PHP',
                        $rel,
                        'Score=' . $score . '; ' . implode(',', $hits)
                    );
                } elseif ($isPhp && $score >= 6) {
                    $this->addFinding(
                        $state,
                        $report,
                        'REVIEW',
                        'SUSPICIOUS_PHP',
                        $rel,
                        'Score=' . $score . '; ' . implode(',', $hits)
                    );
                }
            }
        }
    }

    public function download()
    {
        $token = preg_replace(
            '/[^A-Za-z0-9_\-]/',
            '',
            (string)$this->input->get('token', true)
        );

        $matches = glob(
            $this->dataDir
            . '/UMSR_SECURITY_*_'
            . $token
            . '.txt'
        );

        if (!$matches) {
            show_404();
            return;
        }

        $file = $matches[0];

        header('Content-Type: text/plain; charset=UTF-8');
        header(
            'Content-Disposition: attachment; filename="'
            . basename($file)
            . '"'
        );

        readfile($file);
    }
}
PHP;

$view=<<<'PHP'
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<div class="container-xxl flex-grow-1 container-p-y">

    <div class="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-4">
        <div>
            <h4 class="fw-semibold mb-1">
                <i class="bx bx-shield-quarter me-1"></i>
                Security Center UMS Rappang
            </h4>
            <p class="text-muted mb-0">
                Pemantauan keamanan aplikasi dan deep scan read-only.
            </p>
        </div>

        <span class="badge bg-label-primary">
            Admin Super
        </span>
    </div>

    <div class="card mb-4">

        <div class="card-body">

            <div class="row g-3 align-items-end">

                <div class="col-lg-8">

                    <label class="form-label">
                        Aplikasi yang akan dipindai
                    </label>

                    <select
                        id="securityApp"
                        class="form-select"
                    >
                        <?php foreach ($apps as $key => $name): ?>
                            <option value="<?=htmlspecialchars($key, ENT_QUOTES, 'UTF-8')?>">
                                <?=htmlspecialchars($name, ENT_QUOTES, 'UTF-8')?>
                            </option>
                        <?php endforeach; ?>
                    </select>

                </div>

                <div class="col-lg-4">

                    <button
                        type="button"
                        id="securityStart"
                        class="btn btn-primary w-100"
                    >
                        <i class="bx bx-search-alt-2 me-1"></i>
                        Mulai Deep Scan
                    </button>

                </div>

            </div>

            <div class="alert alert-info mt-3 mb-0">
                Scanner berjalan bertahap maksimal sekitar
                <strong>80 file / 0,85 detik per request</strong>.
                Ini sengaja dibuat ringan agar tidak memicu 504 Gateway Time-out.
            </div>

        </div>

    </div>

    <div
        id="securityPanel"
        class="card mb-4"
        style="display:none"
    >

        <div class="card-body">

            <div class="d-flex justify-content-between align-items-center mb-2">
                <strong id="securityMessage">
                    Menyiapkan scan...
                </strong>

                <span
                    id="securityStatusBadge"
                    class="badge bg-label-info"
                >
                    Berjalan
                </span>
            </div>

            <div class="progress mb-4" style="height:8px;">
                <div
                    id="securityProgress"
                    class="progress-bar"
                    role="progressbar"
                    style="width:0%"
                ></div>
            </div>

            <div class="row g-3">

                <div class="col-6 col-lg">
                    <div class="border rounded p-3 text-center h-100">
                        <div class="text-muted small">
                            File
                        </div>
                        <div class="fs-4 fw-semibold" id="securityFiles">
                            0
                        </div>
                    </div>
                </div>

                <div class="col-6 col-lg">
                    <div class="border rounded p-3 text-center h-100">
                        <div class="text-muted small">
                            Folder
                        </div>
                        <div class="fs-4 fw-semibold" id="securityDirs">
                            0
                        </div>
                    </div>
                </div>

                <div class="col-6 col-lg">
                    <div class="border rounded p-3 text-center h-100">
                        <div class="text-danger small">
                            Kritis
                        </div>
                        <div class="fs-4 fw-semibold text-danger" id="securityCritical">
                            0
                        </div>
                    </div>
                </div>

                <div class="col-6 col-lg">
                    <div class="border rounded p-3 text-center h-100">
                        <div class="text-warning small">
                            Tinggi
                        </div>
                        <div class="fs-4 fw-semibold text-warning" id="securityHigh">
                            0
                        </div>
                    </div>
                </div>

                <div class="col-6 col-lg">
                    <div class="border rounded p-3 text-center h-100">
                        <div class="text-muted small">
                            Review
                        </div>
                        <div class="fs-4 fw-semibold" id="securityReview">
                            0
                        </div>
                    </div>
                </div>

            </div>

            <div class="mt-3 small text-muted">
                Error scan:
                <strong id="securityErrors">0</strong>
            </div>

            <a
                id="securityDownload"
                href="#"
                class="btn btn-outline-primary mt-3"
                style="display:none"
            >
                <i class="bx bx-download me-1"></i>
                Download TXT Report
            </a>

        </div>

    </div>

    <div class="card">

        <div class="card-body">

            <h6 class="mb-2">
                Kebijakan Keamanan
            </h6>

            <p class="mb-0 text-muted">
                Security Center hanya membaca file.
                Hasil <strong>TINGGI</strong> dan <strong>REVIEW</strong>
                tidak pernah dihapus otomatis.
                Exact hash IOC ditandai <strong>KRITIS</strong>.
            </p>

        </div>

    </div>

</div>

<script>
(function () {

    var baseUrl =
        '<?=rtrim(site_url('admin/security_center'), '/')?>';

    var token = null;
    var batchNumber = 0;
    var busy = false;

    var btn = document.getElementById('securityStart');
    var panel = document.getElementById('securityPanel');
    var message = document.getElementById('securityMessage');
    var progress = document.getElementById('securityProgress');
    var badge = document.getElementById('securityStatusBadge');
    var download = document.getElementById('securityDownload');

    function getJson(url) {

        return fetch(
            url,
            {
                credentials: 'same-origin',
                cache: 'no-store'
            }
        ).then(function (response) {

            if (!response.ok) {
                throw new Error(
                    'HTTP ' + response.status
                );
            }

            return response.json();
        });
    }

    function setValue(id, value) {

        var el = document.getElementById(id);

        if (el) {
            el.textContent = value;
        }
    }

    function updateState(state) {

        state = state || {};

        setValue(
            'securityFiles',
            state.files || 0
        );

        setValue(
            'securityDirs',
            state.dirs || 0
        );

        setValue(
            'securityCritical',
            state.critical || 0
        );

        setValue(
            'securityHigh',
            state.high || 0
        );

        setValue(
            'securityReview',
            state.review || 0
        );

        setValue(
            'securityErrors',
            state.errors || 0
        );
    }

    btn.addEventListener('click', function () {

        if (busy) {
            return;
        }

        busy = true;
        btn.disabled = true;
        panel.style.display = 'block';
        download.style.display = 'none';

        token = null;
        batchNumber = 0;

        progress.style.width = '4%';

        badge.className =
            'badge bg-label-info';

        badge.textContent =
            'Berjalan';

        message.textContent =
            'Membuat sesi scan...';

        updateState({});

        var app =
            document.getElementById(
                'securityApp'
            ).value;

        getJson(
            baseUrl
            + '/start?app='
            + encodeURIComponent(app)
        )
        .then(function (result) {

            if (!result.ok) {
                throw new Error(
                    result.msg || 'Gagal memulai scan.'
                );
            }

            token = result.token;

            runBatch();
        })
        .catch(function (error) {

            stopWithError(
                error.message
            );
        });
    });

    function runBatch() {

        batchNumber++;

        message.textContent =
            'Scanning batch '
            + batchNumber
            + '...';

        getJson(
            baseUrl
            + '/batch?token='
            + encodeURIComponent(token)
        )
        .then(function (result) {

            if (!result.ok) {
                throw new Error(
                    result.msg || 'Batch scan gagal.'
                );
            }

            updateState(
                result.state
            );

            var pseudo =
                Math.min(
                    94,
                    8 + ((batchNumber % 22) * 4)
                );

            progress.style.width =
                pseudo + '%';

            if (result.done) {

                progress.style.width =
                    '100%';

                message.textContent =
                    'Scan selesai.';

                badge.className =
                    'badge bg-label-success';

                badge.textContent =
                    'Selesai';

                download.href =
                    baseUrl
                    + '/download?token='
                    + encodeURIComponent(token);

                download.style.display =
                    'inline-flex';

                busy = false;
                btn.disabled = false;

                return;
            }

            // Jeda kecil supaya browser/server tidak dihantam request berturut-turut.
            window.setTimeout(
                runBatch,
                250
            );
        })
        .catch(function (error) {

            stopWithError(
                error.message
            );
        });
    }

    function stopWithError(text) {

        busy = false;
        btn.disabled = false;

        badge.className =
            'badge bg-label-danger';

        badge.textContent =
            'Berhenti';

        message.textContent =
            'Scan berhenti: ' + text;
    }

})();
</script>
PHP;

write_file_safe(
    $root.'/application/controllers/admin/Security_center.php',
    $controller
);

write_file_safe(
    $root.'/application/views/admin/security_center/index.php',
    $view
);

/*
|--------------------------------------------------------------------------
| 1. Bersihkan salah sisip pada partial PDDIKTI
|--------------------------------------------------------------------------
*/
$wrong = $root.'/application/views/templates/partials/menu_pddikti_feeder_integrasi_v94.php';

$removedWrong = false;

if (is_file($wrong)) {

    $content = @file_get_contents($wrong);

    if (
        $content !== false
        &&
        strpos($content, 'admin/security_center') !== false
    ) {

        backup_file(
            $wrong,
            'security_center_v2_before_cleanup'
        );

        $oldBlock=<<<'PHP'

<?php if ((int)$this->session->userdata('id_user') === 1): ?>
<li class="menu-item">
  <a href="<?= site_url('admin/security_center') ?>" class="menu-link">
    <i class="menu-icon tf-icons bx bx-shield-quarter"></i>
    <div>Security Center</div>
  </a>
</li>
<?php endif; ?>
PHP;

        $newContent = str_replace(
            $oldBlock,
            '',
            $content
        );

        if ($newContent === $content) {

            $newContent = preg_replace(
                '#<\?php\s+if\s*\(\(int\)\$this->session->userdata\([\'"]id_user[\'"]\)\s*===\s*1\)\s*:\s*\?>\s*<li[^>]*>.*?admin/security_center.*?</li>\s*<\?php\s+endif;\s*\?>#is',
                '',
                $content,
                1
            );
        }

        if ($newContent !== null && $newContent !== $content) {
            @file_put_contents(
                $wrong,
                $newContent
            );
            $removedWrong = true;
        }
    }
}

/*
|--------------------------------------------------------------------------
| 2. Pasang hanya pada menu utama Admin Super
|--------------------------------------------------------------------------
*/
$menu = $root.'/application/views/templates/menu.php';

if (!is_file($menu)) {
    die(
        'ERROR: menu utama tidak ditemukan: '
        . htmlspecialchars($menu)
    );
}

$menuContent = @file_get_contents($menu);

if ($menuContent === false) {
    die('ERROR: tidak dapat membaca templates/menu.php');
}

$menuAdded = false;

if (strpos($menuContent, 'admin/security_center') === false) {

    backup_file(
        $menu,
        'security_center_v2'
    );

    $menuBlock=<<<'PHP'

<!-- SECURITY_CENTER_UMSR_START -->
<?php if ((int)$this->session->userdata('id_user') === 1): ?>
<li class="menu-item <?= (isset($this->uri) && $this->uri->segment(1) === 'admin' && strtolower((string)$this->uri->segment(2)) === 'security_center') ? 'active' : '' ?>">
    <a href="<?= site_url('admin/security_center') ?>" class="menu-link">
        <i class="menu-icon tf-icons bx bx-shield-quarter"></i>
        <div data-i18n="Security Center">Security Center</div>
    </a>
</li>
<?php endif; ?>
<!-- SECURITY_CENTER_UMSR_END -->
PHP;

    $lastUl = strripos(
        $menuContent,
        '</ul>'
    );

    if ($lastUl === false) {
        die(
            'ERROR: struktur </ul> tidak ditemukan pada templates/menu.php. Tidak ada perubahan menu.'
        );
    }

    $menuContent =
        substr($menuContent, 0, $lastUl)
        . $menuBlock
        . "\n"
        . substr($menuContent, $lastUl);

    if (@file_put_contents($menu, $menuContent) === false) {
        die('ERROR: gagal menulis templates/menu.php');
    }

    $menuAdded = true;
}

/*
|--------------------------------------------------------------------------
| Output
|--------------------------------------------------------------------------
*/
echo '<!doctype html><meta charset="utf-8">';
echo '<style>';
echo 'body{font:14px Arial;background:#f5f7fb;padding:28px;color:#1f2937}';
echo '.box{max-width:950px;margin:auto;background:#fff;border-radius:12px;padding:24px}';
echo '.ok{color:#047857}.warn{color:#b45309}code{background:#f3f4f6;padding:3px 6px;word-break:break-all}';
echo '</style>';

echo '<div class="box">';
echo '<h2>Security Center UMSR V2 — PATCH OK</h2>';

echo '<p class="ok"><b>Controller:</b> diperbarui.</p>';
echo '<p class="ok"><b>View:</b> diperbarui dan sekarang memakai template portal Sneat.</p>';

echo '<p><b>Menu utama:</b> <code>'
    . htmlspecialchars($menu)
    . '</code></p>';

echo '<p><b>Status menu:</b> '
    . ($menuAdded
        ? '<span class="ok">ditambahkan ke templates/menu.php</span>'
        : '<span class="ok">sudah tersedia di templates/menu.php</span>')
    . '</p>';

echo '<p><b>Partial PDDIKTI:</b> '
    . ($removedWrong
        ? '<span class="ok">sisipan Security Center yang salah sudah dibersihkan</span>'
        : '<span class="ok">tidak ada sisipan salah yang perlu dibersihkan</span>')
    . '</p>';

echo '<p><b>Akses:</b> hanya <code>id_user = 1</code>.</p>';

echo '<hr>';

echo '<p><b>SELESAI:</b> hapus file <code>'
    . htmlspecialchars(basename(__FILE__))
    . '</code> setelah screenshot hasil ini.</p>';

echo '<p>Setelah itu login Admin Super dan buka menu <b>Security Center</b>.</p>';

echo '</div>';
