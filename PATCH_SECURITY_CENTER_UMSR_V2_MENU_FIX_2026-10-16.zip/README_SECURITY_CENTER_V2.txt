PATCH SECURITY CENTER UMSR V2 - 2026-10-16

PERBAIKAN V2
- Menghapus salah sisip Security Center dari:
  application/views/templates/partials/menu_pddikti_feeder_integrasi_v94.php
- Memasang menu hanya pada:
  application/views/templates/menu.php
- Menu dan controller hanya untuk id_user=1.
- Halaman sekarang dirender di dalam template portal:
  templates/header -> templates/menu -> admin/security_center/index -> templates/footer.
- UI mengikuti card/Sneat portal.
- Deep scan tetap read-only.
- Batch diperkecil menjadi maksimal 80 file atau sekitar 0,85 detik per request.
- Jeda AJAX 250 ms antar-batch untuk mengurangi beban server dan mencegah 504.
- TXT report tetap tersedia.

CARA PASANG
1. Extract ZIP ke root siakad_new_migrasi.
2. Pastikan install_security_center_v2.php sejajar index.php dan application/.
3. Buka install_security_center_v2.php sekali dari browser.
4. Pastikan muncul "PATCH OK".
5. Hapus install_security_center_v2.php.
6. Login sebagai Admin Super id_user=1.
7. Buka menu Security Center.
8. Jalankan scan satu aplikasi lalu Download TXT Report.

CATATAN
- Patch membuat backup sebelum memperbaiki menu.
- Tidak mengubah partial PDDIKTI selain membuang sisipan Security Center yang sebelumnya salah.
- Scanner tidak menghapus atau mengarantina file.
